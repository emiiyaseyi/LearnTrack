<?php
/**
 * Branding & Customisation page for Learning Path Progress.
 */
require_once(__DIR__ . '/../../config.php');

require_login();
$syscontext = context_system::instance();
require_capability('local/learnpath:manage', $syscontext);

$PAGE->set_url(new moodle_url('/local/learnpath/branding.php'));
$PAGE->set_context($syscontext);
$PAGE->set_pagelayout('report');
$PAGE->set_title('Branding & Customisation');
$PAGE->set_heading('Branding & Customisation');
$PAGE->requires->css('/local/learnpath/styles.css');

global $OUTPUT, $CFG;

$saved = false;
$errors = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST' && confirm_sesskey()) {
    // Sanitise and save all branding settings
    $fields = [
        'brand_name'         => PARAM_TEXT,
        'brand_color'        => PARAM_TEXT,
        'brand_accent'       => PARAM_TEXT,
        'brand_font'         => PARAM_ALPHA,
        'brand_logo_url'     => PARAM_URL,
        'brand_font_size'    => PARAM_INT,
        'show_grade'         => PARAM_INT,
        'show_timespent'     => PARAM_INT,
        'show_firstaccess'   => PARAM_INT,
        'show_lastaccess'    => PARAM_INT,
        'show_activities'    => PARAM_INT,
        'show_status'        => PARAM_INT,
        'high_contrast'      => PARAM_INT,
        'large_text'         => PARAM_INT,
        'reduce_motion'      => PARAM_INT,
        'export_format'      => PARAM_ALPHA,
        'rows_per_page'      => PARAM_INT,
        'dashboard_subtitle' => PARAM_TEXT,
    ];
    foreach ($fields as $key => $type) {
        $val = optional_param($key, '', $type);
        if ($type === PARAM_INT && !isset($_POST[$key])) {
            $val = 0; // checkboxes
        }
        set_config($key, $val, 'local_learnpath');
    }
    $saved = true;
}

// Load current values
function lp_cfg(string $key, $default = '') {
    $val = get_config('local_learnpath', $key);
    return ($val !== false && $val !== null && $val !== '') ? $val : $default;
}

echo $OUTPUT->header();
?>
<style>
.lp-branding-page { max-width: 860px; }
.lp-section { background: white; border: 1px solid #e5e7eb; border-radius: 12px; margin-bottom: 20px; overflow: hidden; }
.lp-section-header {
    background: #f8fafc; border-bottom: 1px solid #e5e7eb;
    padding: 14px 20px; display: flex; align-items: center; gap: 10px;
}
.lp-section-icon { font-size: 1.2rem; }
.lp-section-title { font-size: .95rem; font-weight: 700; color: #111827; font-family: var(--lp-font); margin: 0; }
.lp-section-body { padding: 20px; }
.lp-field-row { display: grid; grid-template-columns: 1fr 1fr; gap: 16px; margin-bottom: 16px; }
.lp-field-row.full { grid-template-columns: 1fr; }
@media(max-width:640px){ .lp-field-row { grid-template-columns: 1fr; } }
.lp-field { display: flex; flex-direction: column; gap: 5px; }
.lp-field label { font-size: .78rem; font-weight: 600; color: #374151; text-transform: uppercase; letter-spacing: .4px; font-family: var(--lp-font); }
.lp-field input[type=text], .lp-field input[type=url], .lp-field select {
    font-family: var(--lp-font); font-size: .88rem;
    border: 1.5px solid #e5e7eb; border-radius: 8px; padding: 8px 12px;
    background: #f9fafb; color: #111827; outline: none; transition: border-color .15s;
}
.lp-field input:focus, .lp-field select:focus { border-color: var(--lp-primary, #1a56db); background: white; }
.lp-field input[type=color] {
    width: 48px; height: 36px; border: 1.5px solid #e5e7eb;
    border-radius: 8px; cursor: pointer; padding: 2px;
}
.lp-color-row { display: flex; align-items: center; gap: 10px; }
.lp-color-preview { flex: 1; height: 36px; border-radius: 8px; border: 1px solid #e5e7eb; transition: background .2s; }
.lp-field-hint { font-size: .74rem; color: #9ca3af; font-family: var(--lp-font); }
.lp-toggle-row { display: flex; align-items: center; justify-content: space-between; padding: 10px 0; border-bottom: 1px solid #f3f4f6; }
.lp-toggle-row:last-child { border-bottom: none; }
.lp-toggle-label { font-family: var(--lp-font); }
.lp-toggle-label strong { font-size: .88rem; color: #111827; display: block; }
.lp-toggle-label span { font-size: .76rem; color: #9ca3af; }
.lp-switch { position: relative; width: 44px; height: 24px; }
.lp-switch input { opacity: 0; width: 0; height: 0; }
.lp-switch-slider {
    position: absolute; inset: 0; background: #d1d5db;
    border-radius: 100px; cursor: pointer; transition: .2s;
}
.lp-switch-slider:before {
    content: ''; position: absolute;
    width: 18px; height: 18px; left: 3px; bottom: 3px;
    background: white; border-radius: 50%; transition: .2s;
    box-shadow: 0 1px 3px rgba(0,0,0,.2);
}
.lp-switch input:checked + .lp-switch-slider { background: #1a56db; }
.lp-switch input:checked + .lp-switch-slider:before { transform: translateX(20px); }
.lp-save-bar {
    position: sticky; bottom: 0; background: white;
    border-top: 1px solid #e5e7eb; padding: 14px 0; margin-top: 20px;
    display: flex; align-items: center; gap: 12px; z-index: 10;
}
.lp-preview-strip {
    border-radius: 10px; padding: 14px 18px; margin-bottom: 16px;
    font-family: var(--lp-font); font-size: .88rem;
    display: flex; align-items: center; gap: 12px;
    transition: all .3s;
}
</style>

<?php
// Back link
echo html_writer::link(new moodle_url('/local/learnpath/welcome.php'), '← Back to Welcome', ['class' => 'lp-back-link', 'style' => 'display:inline-block;margin-bottom:16px;font-family:var(--lp-font);font-size:.85rem;color:#1a56db;text-decoration:none']);

if ($saved) {
    echo $OUTPUT->notification('Branding settings saved successfully! Refresh the dashboard to see changes.', 'success');
}

echo '<div class="lp-branding-page">';
echo html_writer::tag('h1', '🎨 Branding & Customisation', ['style' => 'font-family:var(--lp-font);font-size:1.5rem;font-weight:800;color:#111827;margin:0 0 6px']);
echo html_writer::tag('p', 'Customise the plugin\'s appearance, visible fields, and accessibility features.', ['style' => 'font-family:var(--lp-font);color:#6b7280;margin:0 0 20px;font-size:.9rem']);

echo '<form method="post" action="">';
echo html_writer::empty_tag('input', ['type' => 'hidden', 'name' => 'sesskey', 'value' => sesskey()]);

// ── IDENTITY ──────────────────────────────────────────────────────────────────
echo '<div class="lp-section">';
echo '<div class="lp-section-header"><span class="lp-section-icon">🏷️</span><h3 class="lp-section-title">Plugin Identity</h3></div>';
echo '<div class="lp-section-body">';
echo '<div class="lp-field-row">';
echo lp_field('brand_name', 'Plugin Display Name', lp_cfg('brand_name', 'Learning Path Progress'), 'text', 'Shown in the header and navigation');
echo lp_field('dashboard_subtitle', 'Dashboard Subtitle', lp_cfg('dashboard_subtitle', 'Track learner progress across all courses in a learning path — from one place.'), 'text', 'Subtitle shown below the dashboard heading');
echo '</div>';
echo lp_field('brand_logo_url', 'Logo URL (optional)', lp_cfg('brand_logo_url', ''), 'url', 'Full URL to your logo image (PNG/SVG recommended, max 48px height)', true);
echo '</div></div>';

// ── COLOURS ───────────────────────────────────────────────────────────────────
echo '<div class="lp-section">';
echo '<div class="lp-section-header"><span class="lp-section-icon">🎨</span><h3 class="lp-section-title">Colours</h3></div>';
echo '<div class="lp-section-body">';

// Live preview
echo '<div class="lp-preview-strip" id="lp-preview" style="background:' . lp_cfg('brand_color', '#1a56db') . ';color:white">';
echo '<span style="font-size:1.5rem">🎨</span>';
echo '<div><strong>Preview:</strong> This is how your primary colour looks in headers and buttons.</div>';
echo '</div>';

echo '<div class="lp-field-row">';
echo '<div class="lp-field"><label>Primary Colour</label><div class="lp-color-row">';
echo '<input type="color" name="brand_color" id="brand_color" value="' . lp_cfg('brand_color', '#1a56db') . '" oninput="document.getElementById(\'lp-preview\').style.background=this.value;document.getElementById(\'brand_color_text\').value=this.value">';
echo '<input type="text" id="brand_color_text" value="' . lp_cfg('brand_color', '#1a56db') . '" style="width:100px" oninput="document.getElementById(\'brand_color\').value=this.value">';
echo '<div class="lp-color-preview" id="color_preview" style="background:' . lp_cfg('brand_color', '#1a56db') . '"></div>';
echo '</div><span class="lp-field-hint">Used for header gradient, buttons, active states</span></div>';

echo '<div class="lp-field"><label>Accent Colour</label><div class="lp-color-row">';
echo '<input type="color" name="brand_accent" id="brand_accent" value="' . lp_cfg('brand_accent', '#059669') . '">';
echo '<input type="text" value="' . lp_cfg('brand_accent', '#059669') . '" style="width:100px">';
echo '<div class="lp-color-preview" style="background:' . lp_cfg('brand_accent', '#059669') . '"></div>';
echo '</div><span class="lp-field-hint">Used for success badges, completed status</span></div>';
echo '</div>';
echo '</div></div>';

// ── TYPOGRAPHY ────────────────────────────────────────────────────────────────
echo '<div class="lp-section">';
echo '<div class="lp-section-header"><span class="lp-section-icon">✍️</span><h3 class="lp-section-title">Typography</h3></div>';
echo '<div class="lp-section-body"><div class="lp-field-row">';

$fonts = ['DMSans' => 'DM Sans (Default)', 'Inter' => 'Inter', 'Roboto' => 'Roboto', 'OpenSans' => 'Open Sans', 'Lato' => 'Lato', 'Nunito' => 'Nunito', 'system' => 'System Default'];
echo '<div class="lp-field"><label>Font Family</label>';
echo '<select name="brand_font">';
foreach ($fonts as $val => $label) {
    $sel = lp_cfg('brand_font', 'DMSans') === $val ? ' selected' : '';
    echo '<option value="' . $val . '"' . $sel . '>' . $label . '</option>';
}
echo '</select><span class="lp-field-hint">Applied to all plugin text</span></div>';

$sizes = [12 => 'Small (12px)', 13 => 'Default (13px)', 14 => 'Medium (14px)', 16 => 'Large (16px)', 18 => 'Extra Large (18px)'];
echo '<div class="lp-field"><label>Base Font Size</label>';
echo '<select name="brand_font_size">';
foreach ($sizes as $val => $label) {
    $sel = (int)lp_cfg('brand_font_size', 13) === $val ? ' selected' : '';
    echo '<option value="' . $val . '"' . $sel . '>' . $label . '</option>';
}
echo '</select><span class="lp-field-hint">Affects table and label text size</span></div>';

echo '</div></div></div>';

// ── VISIBLE FIELDS ────────────────────────────────────────────────────────────
echo '<div class="lp-section">';
echo '<div class="lp-section-header"><span class="lp-section-icon">👁️</span><h3 class="lp-section-title">Visible Report Fields</h3></div>';
echo '<div class="lp-section-body">';
$toggles = [
    ['show_status',      'Completion Status',    'Show the status badge (Completed / In Progress / Not Started)'],
    ['show_grade',       'Grade / Score',         'Show the learner\'s grade out of max grade'],
    ['show_activities',  'Activity Count',        'Show completed activities vs total activities'],
    ['show_firstaccess', 'First Access Date',     'Show when the learner first opened the course'],
    ['show_lastaccess',  'Last Access Date',      'Show when the learner last accessed the course'],
    ['show_timespent',   'Time Spent (approx)',   'Approximate time spent based on log entries'],
];
foreach ($toggles as [$key, $label, $hint]) {
    $checked = lp_cfg($key, 1) ? 'checked' : '';
    echo '<div class="lp-toggle-row">';
    echo '<div class="lp-toggle-label"><strong>' . $label . '</strong><span>' . $hint . '</span></div>';
    echo '<label class="lp-switch"><input type="checkbox" name="' . $key . '" value="1" ' . $checked . '><span class="lp-switch-slider"></span></label>';
    echo '</div>';
}
echo '</div></div>';

// ── EXPORT DEFAULTS ───────────────────────────────────────────────────────────
echo '<div class="lp-section">';
echo '<div class="lp-section-header"><span class="lp-section-icon">📤</span><h3 class="lp-section-title">Export & Pagination</h3></div>';
echo '<div class="lp-section-body"><div class="lp-field-row">';
$formats = ['xlsx' => 'Excel (.xlsx)', 'csv' => 'CSV', 'pdf' => 'PDF'];
echo '<div class="lp-field"><label>Default Export Format</label><select name="export_format">';
foreach ($formats as $val => $label) {
    $sel = lp_cfg('export_format', 'xlsx') === $val ? ' selected' : '';
    echo '<option value="' . $val . '"' . $sel . '>' . $label . '</option>';
}
echo '</select></div>';
$rows = [25 => '25 rows', 50 => '50 rows', 100 => '100 rows', 250 => '250 rows', 0 => 'All rows'];
echo '<div class="lp-field"><label>Rows Per Page</label><select name="rows_per_page">';
foreach ($rows as $val => $label) {
    $sel = (int)lp_cfg('rows_per_page', 50) === $val ? ' selected' : '';
    echo '<option value="' . $val . '"' . $sel . '>' . $label . '</option>';
}
echo '</select></div>';
echo '</div></div></div>';

// ── ACCESSIBILITY ─────────────────────────────────────────────────────────────
echo '<div class="lp-section">';
echo '<div class="lp-section-header"><span class="lp-section-icon">♿</span><h3 class="lp-section-title">Accessibility</h3></div>';
echo '<div class="lp-section-body">';
$a11y = [
    ['high_contrast',  'High Contrast Mode',   'Increase colour contrast for better visibility'],
    ['large_text',     'Larger Text Mode',      'Apply larger base font size throughout the plugin'],
    ['reduce_motion',  'Reduce Motion',         'Disable transitions and animations'],
];
foreach ($a11y as [$key, $label, $hint]) {
    $checked = lp_cfg($key, 0) ? 'checked' : '';
    echo '<div class="lp-toggle-row">';
    echo '<div class="lp-toggle-label"><strong>' . $label . '</strong><span>' . $hint . '</span></div>';
    echo '<label class="lp-switch"><input type="checkbox" name="' . $key . '" value="1" ' . $checked . '><span class="lp-switch-slider"></span></label>';
    echo '</div>';
}
echo '</div></div>';

// ── SAVE BAR ──────────────────────────────────────────────────────────────────
echo '<div class="lp-save-bar">';
echo '<button type="submit" class="lp-btn lp-btn-primary" style="font-family:var(--lp-font)">💾 Save Branding Settings</button>';
echo html_writer::link(new moodle_url('/local/learnpath/welcome.php'), 'Cancel', ['class' => 'lp-btn lp-btn-export', 'style' => 'font-family:var(--lp-font)']);
echo '</div>';

echo '</form></div>';
echo $OUTPUT->footer();

// Helper
function lp_field(string $name, string $label, string $val, string $type = 'text', string $hint = '', bool $full = false): string {
    $html  = '<div class="lp-field' . ($full ? ' full' : '') . '">';
    $html .= '<label for="' . $name . '">' . $label . '</label>';
    $html .= '<input type="' . $type . '" id="' . $name . '" name="' . $name . '" value="' . htmlspecialchars($val) . '">';
    if ($hint) $html .= '<span class="lp-field-hint">' . $hint . '</span>';
    $html .= '</div>';
    return $html;
}
