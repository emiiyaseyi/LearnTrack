<?php
defined('MOODLE_INTERNAL') || die();

// Core
$string['pluginname']       = 'Learning Path Progress';
$string['dashboard_title']  = 'Learning Path Progress Dashboard';
$string['manage_paths']     = 'Manage Learning Paths';
$string['manage_paths_link'] = 'Go to Learning Path Manager';

// Capabilities
$string['learnpath:viewdashboard'] = 'View Learning Path Dashboard';
$string['learnpath:manage']        = 'Manage Learning Path Groups';
$string['learnpath:export']        = 'Export Learning Path Reports';
$string['learnpath:emailreport']   = 'Send/Schedule Email Reports';
$string['learnpath:viewall']       = 'View All Learners (ignore group restriction)';

// Navigation
$string['back_to_dashboard'] = 'Back to Dashboard';

// Settings
$string['setting_restrict_by_group']      = 'Restrict visibility by group/cohort';
$string['setting_restrict_by_group_desc'] = 'When enabled, managers and teachers will only see learners who share a group or cohort with them. Admins with the "View All" capability always see everyone.';
$string['setting_allowed_roles']          = 'Roles allowed to view the dashboard';
$string['setting_allowed_roles_desc']     = 'Select which Moodle roles can access the Learning Path Progress dashboard.';
$string['setting_default_export']         = 'Default export format';
$string['setting_default_export_desc']    = 'The default format used when exporting reports.';
$string['setting_email_sender']           = 'Email sender name';
$string['setting_email_sender_desc']      = 'The name that appears as the sender of scheduled report emails.';

// Dashboard
$string['select_group']        = 'Select a learning path';
$string['select_group_prompt'] = 'Please select a learning path group from the dropdown to view learner progress.';
$string['search_learner']      = 'Filter by learner name or email…';
$string['view']                = 'View mode';
$string['view_detail']         = 'Per-course detail';
$string['view_summary']        = 'Learner summary';
$string['no_data']             = 'No data found for the selected group and current filters.';

// Group management
$string['add_group']              = 'Add Learning Path';
$string['edit_group']             = 'Edit Learning Path';
$string['group_name']             = 'Path name';
$string['group_description']      = 'Description';
$string['group_type']             = 'Group type';
$string['group_type_help']        = 'Choose how courses are grouped: manually pick courses, by category, or by cohort.';
$string['group_category']         = 'Course category';
$string['group_cohort']           = 'Cohort';
$string['group_courses']          = 'Courses';
$string['group_coursecount']      = 'Courses';
$string['group_saved']            = 'Learning path saved successfully.';
$string['group_deleted']          = 'Learning path deleted.';
$string['no_groups']              = 'No learning paths have been created yet.';
$string['confirm_delete_group']   = 'Are you sure you want to delete this learning path? All associated schedules will also be removed.';
$string['grouptype_manual']       = 'Manual course selection';
$string['grouptype_category']     = 'By course category';
$string['grouptype_cohort']       = 'By cohort';
$string['invalidgroup']           = 'Invalid learning path group.';

// Schedules
$string['manage_schedules']       = 'Manage Scheduled Reports';
$string['add_schedule']           = 'Add Schedule';
$string['edit_schedule']          = 'Edit Schedule';
$string['schedule_recipients']    = 'Email recipients';
$string['schedule_recipients_help'] = 'Enter one or more email addresses separated by commas.';
$string['recipients_help']        = 'Separate multiple email addresses with commas.';
$string['schedule_frequency']     = 'Frequency';
$string['schedule_format']        = 'Report format';
$string['schedule_enabled']       = 'Enabled';
$string['schedule_nextrun']       = 'Next run';
$string['schedule_lastrun']       = 'Last run';
$string['schedule_saved']         = 'Schedule saved successfully.';
$string['schedule_deleted']       = 'Schedule deleted.';
$string['no_schedules']           = 'No scheduled reports have been set up for this learning path.';
$string['confirm_delete_schedule'] = 'Are you sure you want to delete this scheduled report?';
$string['frequency_daily']        = 'Daily';
$string['frequency_weekly']       = 'Weekly';
$string['frequency_monthly']      = 'Monthly';

// Email
$string['send_email_now']         = 'Send Report by Email';
$string['email_sent_success']     = 'Report sent successfully.';
$string['error_no_recipients']    = 'Please enter at least one valid email address.';
$string['error_email_failed']     = 'One or more emails could not be sent. Please check server mail settings.';
$string['email_subject']          = 'Learning Path Progress Report: {$a}';
$string['email_body']             = "Dear Recipient,\n\nPlease find attached the progress report for learning path: {$a->groupname}.\n\nReport date: {$a->date}\nTotal records: {$a->count}\n\nThis report was generated automatically by Moodle.\n\nRegards,\nMoodle LearnPath Plugin";

// Table columns
$string['col_firstname']            = 'First name';
$string['col_lastname']             = 'Last name';
$string['col_email']                = 'Email';
$string['col_username']             = 'Username';
$string['col_coursename']           = 'Course';
$string['col_status']               = 'Status';
$string['col_progress']             = 'Progress';
$string['col_completed_activities'] = 'Completed activities';
$string['col_total_activities']     = 'Total activities';
$string['col_grade']                = 'Grade';
$string['col_firstaccess']          = 'First access';
$string['col_lastaccess']           = 'Last access';
$string['col_timecompleted']        = 'Date completed';
$string['col_total_courses']        = 'Total courses';
$string['col_completed_courses']    = 'Completed';
$string['col_inprogress_courses']   = 'In progress';
$string['col_notstarted_courses']   = 'Not started';
$string['col_overall_progress']     = 'Overall progress';

// Status labels
$string['status_complete']    = 'Completed';
$string['status_inprogress']  = 'In Progress';
$string['status_notstarted']  = 'Not Started';

// Tasks
$string['task_send_reports']  = 'Send scheduled learning path progress reports';

// Privacy
$string['privacy:metadata'] = 'The Learning Path Progress plugin reads enrolment, completion, grade, and log data from Moodle core tables. It does not store personal data of its own beyond group configurations and schedule settings.';

$string['manage_paths_subtitle'] = 'Create and manage learning path groups. Assign courses, set group types, and configure scheduled reports.';
$string['no_groups_hint']        = 'Create your first learning path to start tracking learner progress across multiple courses.';
$string['admin_only_notice']     = 'Admin-only area';
$string['admin_only_notice_desc']= 'Only users with the Site Administrator or Manager role can access this page.';
$string['admin_access']          = 'Admin Access';
$string['dashboard_subtitle']    = 'Track learner progress across all courses in a learning path — from one place.';
$string['developer_country'] = 'Nigeria';
$string['developer_version'] = 'Version {$a}';
$string['developer_compat']  = 'Compatible with Moodle 4.5, 5.0, 5.1+';
