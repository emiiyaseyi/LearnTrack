# Learning Path Progress Dashboard
### Moodle Local Plugin — local_learnpath

---

**Developer:** Michael Adeniran
**Email:** michaeladeniransnr@gmail.com
**LinkedIn:** https://www.linkedin.com/in/michaeladeniran
**Country:** Nigeria
**Copyright:** (C) 2025 Michael Adeniran
**License:** GNU General Public License v3 or later
**Version:** 1.0.0
**Compatible with:** Moodle 4.5, 5.0, 5.1 and later

---

## What This Plugin Does

Provides a single dashboard where administrators, managers, and teachers can:
- Group courses into named Learning Paths (e.g. "NEO Onboarding")
- View all enrolled learners' progress across every course in the path — without opening each course individually
- See per-learner data: % progress, first access, last access, completion status, activities completed, grade
- Switch between **per-course detail view** and **learner summary view**
- Export reports as **Excel (.xlsx)**, **CSV**, or **PDF**
- Send reports by **email on demand** or on a **scheduled basis** (daily / weekly / monthly)

---

## Installation — Method 1: Via Moodle Admin UI (Recommended)

Works on **all supported versions** (Moodle 4.5, 5.0, 5.1+).

1. Log in to Moodle as a **Site Administrator**
2. Go to: **Site Administration → Plugins → Install plugins**
3. Click **"Choose a file"** and upload `local_learnpath.zip`
4. Click **"Install plugin from the ZIP file"**
5. Review the plugin info — confirm it shows `local_learnpath`
6. Click **"Continue"** through the upgrade confirmation screens
7. Done! The plugin is now installed.

---

## Installation — Method 2: Via File Manager / FTP / SSH

### Moodle 4.5 and 5.0

Extract `local_learnpath.zip` and copy the `local_learnpath` folder to:

```
/path/to/moodle/local/learnpath/
```

So the structure looks like:
```
moodle/
  local/
    learnpath/
      version.php
      index.php
      ...
```

### Moodle 5.1 and Later

In Moodle 5.1+, all plugin code lives under the new `/public` directory.
Copy the `local_learnpath` folder to:

```
/path/to/moodle/public/local/learnpath/
```

So the structure looks like:
```
moodle/
  public/
    local/
      learnpath/
        version.php
        index.php
        ...
```

### After Copying Files (All Versions)

1. Visit your Moodle site in a browser as **Site Administrator**
2. Moodle will detect the new plugin and show an upgrade notification
3. Click **"Upgrade Moodle database now"**
4. Follow the on-screen steps to complete installation

---

## After Installation — First Steps

1. Go to **Site Administration → Plugins → Local plugins → Learning Path Progress** to configure settings
2. Set which roles can view the dashboard
3. Choose whether managers see only their own group/cohort or all learners
4. Click the **"Go to Learning Path Manager"** link
5. Click **"Add Learning Path"** to create your first group (e.g. "NEO Onboarding") and select the courses
6. Go to the dashboard via the sidebar navigation or visit `/local/learnpath/index.php`

---

## Permissions / Roles

| Capability                      | Default roles                          |
|---------------------------------|----------------------------------------|
| View dashboard                  | Manager, Course creator, Teacher       |
| Manage learning path groups     | Manager                                |
| Export reports                  | Manager, Course creator, Teacher       |
| Send / schedule email reports   | Manager                                |
| View all learners (no filter)   | Manager                                |

All capabilities can be overridden via **Site Administration → Users → Permissions → Define roles**.

---

## Scheduled Email Reports

- Scheduled reports run via **Moodle's cron** (runs daily at 6:00 AM by default)
- Ensure your Moodle cron is running: `Site Administration → Server → Scheduled tasks`
- You can adjust the schedule of the "Send scheduled learning path reports" task there

---

## Support

For questions, feature requests, or bug reports, contact the developer:
- **Email:** michaeladeniransnr@gmail.com
- **LinkedIn:** https://www.linkedin.com/in/michaeladeniran

---

*This plugin is open source, licensed under the GNU General Public License v3.*
