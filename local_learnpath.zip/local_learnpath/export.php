<?php
require_once(__DIR__ . '/../../config.php');

use local_learnpath\export_manager;

require_login();
require_sesskey();
$syscontext = context_system::instance();
require_capability('local/learnpath:export', $syscontext);

$groupid = required_param('groupid', PARAM_INT);
$format  = required_param('format',  PARAM_ALPHA);
$view    = optional_param('view', 'detail', PARAM_ALPHA);

if (!in_array($format, ['xlsx', 'csv', 'pdf'])) {
    throw new moodle_exception('invalidformat', 'local_learnpath');
}

export_manager::export($groupid, $format, $view, $USER->id);
