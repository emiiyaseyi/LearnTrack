<?php
defined('MOODLE_INTERNAL') || die();

/**
 * Adds plugin link to the navigation.
 */
function local_learnpath_extend_navigation(global_navigation $nav) {
    if (has_capability('local/learnpath:viewdashboard', context_system::instance())) {
        $node = $nav->add(
            get_string('pluginname', 'local_learnpath'),
            new moodle_url('/local/learnpath/welcome.php'),
            navigation_node::TYPE_CUSTOM,
            null,
            'local_learnpath',
            new pix_icon('i/report', '')
        );
        $node->showinflatnavigation = true;
    }
}

/**
 * Adds plugin to admin navigation.
 */
function local_learnpath_extend_settings_navigation(settings_navigation $nav, context $context) {
}
