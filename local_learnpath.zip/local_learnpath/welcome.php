<?php
/**
 * Welcome / About page for Learning Path Progress plugin.
 */
require_once(__DIR__ . '/../../config.php');

require_login();
$syscontext = context_system::instance();
require_capability('local/learnpath:viewdashboard', $syscontext);

$PAGE->set_url(new moodle_url('/local/learnpath/welcome.php'));
$PAGE->set_context($syscontext);
$PAGE->set_pagelayout('report');
$PAGE->set_title('Learning Path Progress — Welcome');
$PAGE->set_heading('Learning Path Progress');
$PAGE->requires->css('/local/learnpath/styles.css');

global $OUTPUT, $DB;

$isadmin   = has_capability('local/learnpath:manage', $syscontext);
$canexport = has_capability('local/learnpath:export', $syscontext);
$groupcount  = $DB->count_records('local_learnpath_groups');
$coursecount = $DB->count_records('local_learnpath_group_courses');

// Branding
$brand_color  = get_config('local_learnpath', 'brand_color')  ?: '#1a56db';
$brand_name   = get_config('local_learnpath', 'brand_name')   ?: 'Learning Path Progress';

echo $OUTPUT->header();
?>
<style>
.lp-welcome-hero {
    background: linear-gradient(135deg, #0f172a 0%, #1e3a5f 55%, <?php echo $brand_color; ?> 100%);
    border-radius: 16px;
    padding: 48px 40px;
    color: white;
    margin-bottom: 28px;
    position: relative;
    overflow: hidden;
}
.lp-welcome-hero::before {
    content: '';
    position: absolute;
    top: -60px; right: -60px;
    width: 300px; height: 300px;
    background: rgba(255,255,255,.04);
    border-radius: 50%;
}
.lp-welcome-hero::after {
    content: '';
    position: absolute;
    bottom: -80px; left: 30%;
    width: 200px; height: 200px;
    background: rgba(255,255,255,.03);
    border-radius: 50%;
}
.lp-hero-inner { position: relative; z-index: 1; }
.lp-hero-badge {
    display: inline-flex; align-items: center; gap: 6px;
    background: rgba(255,255,255,.12); border: 1px solid rgba(255,255,255,.2);
    color: rgba(255,255,255,.9); font-size: .75rem; font-weight: 600;
    padding: 4px 14px; border-radius: 100px; margin-bottom: 16px;
    font-family: var(--lp-font);
}
.lp-hero-title {
    font-size: 2.4rem; font-weight: 800; margin: 0 0 12px;
    font-family: var(--lp-font); letter-spacing: -0.5px;
}
.lp-hero-sub {
    font-size: 1.05rem; color: rgba(255,255,255,.78);
    max-width: 600px; margin: 0 0 28px; line-height: 1.6;
    font-family: var(--lp-font);
}
.lp-hero-actions { display: flex; gap: 12px; flex-wrap: wrap; }
.lp-hero-btn {
    display: inline-flex; align-items: center; gap: 8px;
    font-family: var(--lp-font); font-size: .9rem; font-weight: 600;
    padding: 10px 22px; border-radius: 10px; text-decoration: none !important;
    transition: all .15s;
}
.lp-hero-btn-primary {
    background: white; color: #0f172a !important;
    box-shadow: 0 4px 16px rgba(0,0,0,.2);
}
.lp-hero-btn-primary:hover { transform: translateY(-2px); box-shadow: 0 8px 24px rgba(0,0,0,.25); }
.lp-hero-btn-outline {
    background: rgba(255,255,255,.12); color: white !important;
    border: 1.5px solid rgba(255,255,255,.3);
}
.lp-hero-btn-outline:hover { background: rgba(255,255,255,.2); }
.lp-stat-hero { display: flex; gap: 32px; margin-top: 32px; flex-wrap: wrap; }
.lp-stat-hero-item { text-align: center; }
.lp-stat-hero-value { font-size: 2rem; font-weight: 800; display: block; }
.lp-stat-hero-label { font-size: .75rem; color: rgba(255,255,255,.65); text-transform: uppercase; letter-spacing: .5px; }

.lp-welcome-grid { display: grid; grid-template-columns: 2fr 1fr; gap: 20px; margin-bottom: 24px; }
@media(max-width:900px) { .lp-welcome-grid { grid-template-columns: 1fr; } }

.lp-feature-grid { display: grid; grid-template-columns: repeat(3,1fr); gap: 16px; margin-bottom: 24px; }
@media(max-width:900px) { .lp-feature-grid { grid-template-columns: repeat(2,1fr); } }
@media(max-width:600px) { .lp-feature-grid { grid-template-columns: 1fr; } }

.lp-feature-card {
    background: white; border: 1px solid #e5e7eb; border-radius: 12px;
    padding: 20px; box-shadow: 0 1px 3px rgba(0,0,0,.06);
    transition: transform .15s, box-shadow .15s;
}
.lp-feature-card:hover { transform: translateY(-3px); box-shadow: 0 8px 24px rgba(0,0,0,.08); }
.lp-feature-icon { font-size: 1.8rem; margin-bottom: 10px; }
.lp-feature-title { font-size: .95rem; font-weight: 700; color: #111827; margin: 0 0 6px; font-family: var(--lp-font); }
.lp-feature-desc { font-size: .82rem; color: #6b7280; line-height: 1.5; margin: 0; font-family: var(--lp-font); }

.lp-dev-card {
    background: white; border: 1px solid #e5e7eb; border-radius: 12px;
    padding: 24px; box-shadow: 0 1px 3px rgba(0,0,0,.06);
}
.lp-dev-avatar {
    width: 56px; height: 56px; border-radius: 50%;
    background: linear-gradient(135deg, #1a56db, #0f172a);
    display: flex; align-items: center; justify-content: center;
    font-size: 1.5rem; margin-bottom: 14px;
}
.lp-dev-name { font-size: 1.1rem; font-weight: 700; color: #111827; margin: 0 0 4px; font-family: var(--lp-font); }
.lp-dev-role { font-size: .8rem; color: #6b7280; margin: 0 0 16px; font-family: var(--lp-font); }
.lp-dev-link {
    display: flex; align-items: center; gap: 8px; padding: 8px 0;
    border-top: 1px solid #f3f4f6; font-size: .83rem;
    color: #374151 !important; text-decoration: none !important; font-family: var(--lp-font);
}
.lp-dev-link:hover { color: #1a56db !important; }
.lp-dev-link-icon { width: 28px; text-align: center; font-size: 1rem; }

.lp-quicklinks { display: grid; grid-template-columns: 1fr; gap: 10px; }
.lp-quicklink {
    display: flex; align-items: center; gap: 12px;
    background: #f9fafb; border: 1px solid #e5e7eb; border-radius: 10px;
    padding: 12px 16px; text-decoration: none !important;
    color: #111827 !important; font-family: var(--lp-font);
    transition: all .15s;
}
.lp-quicklink:hover { background: #eff6ff; border-color: #1a56db; color: #1a56db !important; }
.lp-quicklink-icon { font-size: 1.2rem; }
.lp-quicklink-text { font-size: .88rem; font-weight: 600; }
.lp-quicklink-sub { font-size: .75rem; color: #9ca3af; display: block; font-weight: 400; }
.lp-quicklink-arrow { margin-left: auto; color: #d1d5db; font-size: .9rem; }
.lp-quicklink:hover .lp-quicklink-arrow { color: #1a56db; }
</style>

<?php
// Hero
echo '<div class="lp-welcome-hero"><div class="lp-hero-inner">';
echo '<div class="lp-hero-badge">🎓 Moodle Local Plugin · v1.3.0</div>';
echo '<h1 class="lp-hero-title">' . format_string($brand_name) . '</h1>';
echo '<p class="lp-hero-sub">Track learner progress across multiple courses from a single dashboard. Export reports, schedule emails, and manage learning paths — all in one place.</p>';

echo '<div class="lp-hero-actions">';
echo html_writer::link(new moodle_url('/local/learnpath/index.php'), '📊 Open Dashboard', ['class' => 'lp-hero-btn lp-hero-btn-primary']);
if ($isadmin) {
    echo html_writer::link(new moodle_url('/local/learnpath/manage.php'), '⚙️ Manage Paths', ['class' => 'lp-hero-btn lp-hero-btn-outline']);
    echo html_writer::link(new moodle_url('/local/learnpath/branding.php'), '🎨 Branding', ['class' => 'lp-hero-btn lp-hero-btn-outline']);
}
echo '</div>';

echo '<div class="lp-stat-hero">';
echo '<div class="lp-stat-hero-item"><span class="lp-stat-hero-value">' . $groupcount . '</span><span class="lp-stat-hero-label">Learning Paths</span></div>';
echo '<div class="lp-stat-hero-item"><span class="lp-stat-hero-value">' . $coursecount . '</span><span class="lp-stat-hero-label">Courses Tracked</span></div>';
echo '<div class="lp-stat-hero-item"><span class="lp-stat-hero-value">v1.3</span><span class="lp-stat-hero-label">Plugin Version</span></div>';
echo '<div class="lp-stat-hero-item"><span class="lp-stat-hero-value">4.5+</span><span class="lp-stat-hero-label">Moodle Compatible</span></div>';
echo '</div>';

echo '</div></div>';

// Main grid: features + developer card
echo '<div class="lp-welcome-grid">';

// Features
echo '<div>';
echo html_writer::tag('h2', 'What this plugin does', ['style' => 'font-size:1.1rem;font-weight:700;margin:0 0 14px;font-family:var(--lp-font);color:#111827']);
echo '<div class="lp-feature-grid">';
$features = [
    ['📊', 'Progress Dashboard', 'View all learners\' progress across every course in a learning path from one screen.'],
    ['📋', 'Two View Modes', 'Switch between per-course detail view and a learner summary view with overall progress.'],
    ['📤', 'Export Reports', 'Export data as Excel (.xlsx), CSV, or PDF with one click.'],
    ['✉️', 'Email Reports', 'Send reports instantly or schedule them daily, weekly, or monthly.'],
    ['🔍', 'Search & Filter', 'Filter by learner, course, status, grade, or date across all columns.'],
    ['🎨', 'Branding Control', 'Customise plugin name, colours, logo, font, and visible fields.'],
    ['🔒', 'Role-based Access', 'Admin-configurable visibility: restrict by group, cohort, or role.'],
    ['📅', 'Scheduled Reports', 'Automate recurring email reports to any recipient list.'],
    ['🌍', 'Multi-language', 'Built on Moodle language packs — ready for localisation.'],
];
foreach ($features as [$icon, $title, $desc]) {
    echo '<div class="lp-feature-card">';
    echo '<div class="lp-feature-icon">' . $icon . '</div>';
    echo '<p class="lp-feature-title">' . $title . '</p>';
    echo '<p class="lp-feature-desc">' . $desc . '</p>';
    echo '</div>';
}
echo '</div>';
echo '</div>';

// Developer card + Quick links
echo '<div>';
echo '<div class="lp-dev-card" style="margin-bottom:16px">';
echo '<div class="lp-dev-avatar">👨🏾‍💻</div>';
echo '<p class="lp-dev-name">Michael Adeniran</p>';
echo '<p class="lp-dev-role">Plugin Developer · Nigeria 🇳🇬</p>';
echo '<a href="https://www.linkedin.com/in/michaeladeniran" target="_blank" class="lp-dev-link">';
echo '<span class="lp-dev-link-icon">💼</span> linkedin.com/in/michaeladeniran</a>';
echo '<a href="mailto:michaeladeniransnr@gmail.com" class="lp-dev-link">';
echo '<span class="lp-dev-link-icon">✉️</span> michaeladeniransnr@gmail.com</a>';
echo '<div class="lp-dev-link"><span class="lp-dev-link-icon">📦</span> Learning Path Progress v1.3.0</div>';
echo '<div class="lp-dev-link"><span class="lp-dev-link-icon">🛡️</span> GNU GPL v3 · Moodle 4.5 – 5.1+</div>';
echo '</div>';

// Quick links
echo '<div style="font-size:.8rem;font-weight:700;color:#6b7280;text-transform:uppercase;letter-spacing:.5px;margin-bottom:10px;font-family:var(--lp-font)">Quick Navigation</div>';
echo '<div class="lp-quicklinks">';
$links = [
    ['/local/learnpath/index.php',   '📊', 'Dashboard',       'View learner progress'],
    ['/local/learnpath/manage.php',  '⚙️', 'Manage Paths',    'Create & edit learning paths'],
    ['/local/learnpath/branding.php','🎨', 'Branding',        'Customise look & feel'],
    ['/admin/settings.php?section=local_learnpath', '🔧', 'Settings', 'Plugin configuration'],
];
foreach ($links as [$url, $icon, $label, $sub]) {
    echo html_writer::link(new moodle_url($url),
        '<span class="lp-quicklink-icon">' . $icon . '</span>' .
        '<span><span class="lp-quicklink-text">' . $label . '</span><span class="lp-quicklink-sub">' . $sub . '</span></span>' .
        '<span class="lp-quicklink-arrow">→</span>',
        ['class' => 'lp-quicklink']);
}
echo '</div>';
echo '</div>';

echo '</div>'; // end welcome grid

// Footer
echo '<div style="border-top:1px solid #e5e7eb;padding-top:16px;margin-top:8px;font-family:var(--lp-font);font-size:.78rem;color:#9ca3af;display:flex;align-items:center;gap:12px;flex-wrap:wrap">';
echo '<span>© 2025 Michael Adeniran</span>';
echo '<span>·</span>';
echo '<a href="https://www.linkedin.com/in/michaeladeniran" target="_blank" style="color:#1a56db">LinkedIn</a>';
echo '<span>·</span>';
echo '<span>Learning Path Progress · v1.3.0 · Moodle 4.5 – 5.1+</span>';
echo '<span>·</span>';
echo '<span>GNU GPL v3</span>';
echo '</div>';

echo $OUTPUT->footer();
