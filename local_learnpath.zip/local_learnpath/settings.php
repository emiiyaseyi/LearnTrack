<?php
defined('MOODLE_INTERNAL') || die();

if ($hassiteconfig) {
    $settings = new admin_settingpage('local_learnpath', get_string('pluginname', 'local_learnpath'));

    $ADMIN->add('localplugins', $settings);

    // Restrict visibility by group/cohort
    $settings->add(new admin_setting_configcheckbox(
        'local_learnpath/restrict_by_group',
        get_string('setting_restrict_by_group', 'local_learnpath'),
        get_string('setting_restrict_by_group_desc', 'local_learnpath'),
        0
    ));

    // Roles allowed to view dashboard (multi-select)
    $settings->add(new admin_setting_configmultiselect(
        'local_learnpath/allowed_roles',
        get_string('setting_allowed_roles', 'local_learnpath'),
        get_string('setting_allowed_roles_desc', 'local_learnpath'),
        ['manager', 'editingteacher', 'teacher'],
        [
            'manager'        => get_string('manager', 'role'),
            'editingteacher' => get_string('editingteacher', 'role'),
            'teacher'        => get_string('teacher', 'role'),
            'coursecreator'  => get_string('coursecreator', 'role'),
        ]
    ));

    // Default export format
    $settings->add(new admin_setting_configselect(
        'local_learnpath/default_export_format',
        get_string('setting_default_export', 'local_learnpath'),
        get_string('setting_default_export_desc', 'local_learnpath'),
        'xlsx',
        [
            'xlsx' => 'Excel (.xlsx)',
            'csv'  => 'CSV',
            'pdf'  => 'PDF',
        ]
    ));

    // Email sender name
    $settings->add(new admin_setting_configtext(
        'local_learnpath/email_sender_name',
        get_string('setting_email_sender', 'local_learnpath'),
        get_string('setting_email_sender_desc', 'local_learnpath'),
        get_string('pluginname', 'local_learnpath')
    ));

    // Add link to manage learning paths
    $settings->add(new admin_setting_heading(
        'local_learnpath/manage_heading',
        get_string('manage_paths', 'local_learnpath'),
        html_writer::link(
            new moodle_url('/local/learnpath/manage.php'),
            get_string('manage_paths_link', 'local_learnpath')
        )
    ));
}
