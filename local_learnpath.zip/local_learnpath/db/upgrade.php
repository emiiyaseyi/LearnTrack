<?php
// Upgrade steps for local_learnpath.
// This file is required so Moodle does not throw errors when updating
// from a previous installed version of the plugin.

defined('MOODLE_INTERNAL') || die();

function xmldb_local_learnpath_upgrade($oldversion) {
    global $DB, $CFG;
    $dbman = $DB->get_manager();

    // All tables are created via install.xml on first install.
    // Add future upgrade steps here if the schema changes in later versions.
    // Example:
    // if ($oldversion < 2025020100) {
    //     // Add new column to existing table.
    //     $table = new xmldb_table('local_learnpath_groups');
    //     $field = new xmldb_field('newfield', XMLDB_TYPE_TEXT, null, null, null, null, null, 'timemodified');
    //     if (!$dbman->field_exists($table, $field)) {
    //         $dbman->add_field($table, $field);
    //     }
    //     upgrade_plugin_savepoint(true, 2025020100, 'local', 'learnpath');
    // }

    return true;
}
