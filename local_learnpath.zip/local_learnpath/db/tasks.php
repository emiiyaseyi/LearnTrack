<?php
defined('MOODLE_INTERNAL') || die();

$tasks = [
    [
        'classname' => '\local_learnpath\task\send_scheduled_reports',
        'blocking'  => 0,
        'minute'    => '0',
        'hour'      => '6',
        'day'       => '*',
        'month'     => '*',
        'dayofweek' => '*',
        'disabled'  => 0,
    ],
];
