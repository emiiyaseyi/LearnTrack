<?php
defined('MOODLE_INTERNAL') || die();

function xmldb_local_learnpath_install() {
    global $DB;
    return true;
}
