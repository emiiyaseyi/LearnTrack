<?php
require_once(__DIR__ . '/../../config.php');
use local_learnpath\export_manager;
use local_learnpath\data_helper;

require_login();
$syscontext = context_system::instance();
require_capability('local/learnpath:emailreport', $syscontext);

$groupid = required_param('groupid', PARAM_INT);
$group   = data_helper::get_group_with_courses($groupid);
if (!$group) throw new moodle_exception('invalidgroup', 'local_learnpath');

$PAGE->set_url(new moodle_url('/local/learnpath/email.php', ['groupid' => $groupid]));
$PAGE->set_context($syscontext);
$PAGE->set_pagelayout('report');
$PAGE->set_title('Send Report — ' . format_string($group->name));
$PAGE->set_heading('Send Report by Email');
$PAGE->requires->css('/local/learnpath/styles.css');

global $OUTPUT, $USER;

$sent = false; $error = '';
if (optional_param('send', 0, PARAM_INT) && confirm_sesskey()) {
    $recipients = optional_param('recipients', '', PARAM_TEXT);
    $format     = optional_param('format', 'xlsx', PARAM_ALPHA);
    $view       = optional_param('view',   'detail', PARAM_ALPHA);
    $rcptlist   = array_filter(array_map('trim', explode(',', $recipients)));
    if (empty($rcptlist)) {
        $error = 'Please enter at least one valid email address.';
    } else {
        $ok = export_manager::email_report($groupid, $rcptlist, $format, $view, $USER->id);
        if ($ok) { $sent = true; } else { $error = 'One or more emails could not be sent. Check server mail settings.'; }
    }
}

echo $OUTPUT->header();
?>
<style>
.lp-email-page { max-width: 700px; }
.lp-email-hero {
    background: linear-gradient(135deg, #0f172a, #1e40af);
    border-radius: 16px; padding: 28px 32px; color: white;
    margin-bottom: 24px; display: flex; align-items: center; gap: 20px;
    font-family: var(--lp-font);
}
.lp-email-hero-icon { font-size: 2.4rem; flex-shrink: 0; }
.lp-email-hero h2 { font-size: 1.3rem; font-weight: 700; margin: 0 0 4px; }
.lp-email-hero p  { font-size: .85rem; color: rgba(255,255,255,.75); margin: 0; }
.lp-form-section {
    background: white; border: 1px solid #e5e7eb; border-radius: 12px;
    padding: 24px; margin-bottom: 16px; font-family: var(--lp-font);
}
.lp-form-section h3 {
    font-size: .85rem; font-weight: 700; color: #374151;
    text-transform: uppercase; letter-spacing: .5px; margin: 0 0 16px;
    display: flex; align-items: center; gap: 8px;
}
.lp-form-row { display: grid; grid-template-columns: 1fr 1fr; gap: 14px; margin-bottom: 14px; }
@media(max-width:600px){ .lp-form-row { grid-template-columns: 1fr; } }
.lp-form-field { display: flex; flex-direction: column; gap: 5px; }
.lp-form-field label { font-size: .76rem; font-weight: 600; color: #6b7280; text-transform: uppercase; letter-spacing: .4px; }
.lp-form-field textarea, .lp-form-field select {
    font-family: var(--lp-font); font-size: .88rem;
    border: 1.5px solid #e5e7eb; border-radius: 8px; padding: 9px 12px;
    background: #f9fafb; outline: none; transition: border-color .15s, box-shadow .15s;
}
.lp-form-field textarea:focus, .lp-form-field select:focus {
    border-color: #1a56db; box-shadow: 0 0 0 3px rgba(26,86,219,.1); background: white;
}
.lp-success-box {
    background: #d1fae5; border: 1px solid #6ee7b7; border-radius: 12px;
    padding: 16px 20px; display: flex; align-items: center; gap: 12px;
    font-family: var(--lp-font); font-size: .9rem; color: #065f46; margin-bottom: 16px;
}
.lp-error-box {
    background: #fee2e2; border: 1px solid #fca5a5; border-radius: 12px;
    padding: 16px 20px; font-family: var(--lp-font); font-size: .9rem;
    color: #991b1b; margin-bottom: 16px;
}
.lp-format-grid { display: grid; grid-template-columns: repeat(3,1fr); gap: 10px; }
.lp-format-option { display: none; }
.lp-format-label {
    border: 2px solid #e5e7eb; border-radius: 10px; padding: 12px;
    text-align: center; cursor: pointer; font-family: var(--lp-font);
    transition: all .15s; display: block;
}
.lp-format-label .fmt-icon { font-size: 1.5rem; display: block; margin-bottom: 4px; }
.lp-format-label .fmt-name { font-size: .82rem; font-weight: 600; color: #374151; }
.lp-format-label .fmt-desc { font-size: .72rem; color: #9ca3af; }
.lp-format-option:checked + .lp-format-label {
    border-color: #1a56db; background: #eff6ff;
}
.lp-form-actions { display: flex; align-items: center; gap: 12px; flex-wrap: wrap; margin-top: 20px; }
</style>

<?php
echo html_writer::link(new moodle_url('/local/learnpath/index.php', ['groupid' => $groupid]), '← Back to Dashboard', ['style' => 'display:inline-block;margin-bottom:16px;font-family:var(--lp-font);font-size:.85rem;color:#1a56db;text-decoration:none']);

if ($sent) {
    echo '<div class="lp-success-box">✅ &nbsp;<div><strong>Report sent successfully!</strong><br>Recipients will receive the report in their inbox shortly.</div></div>';
}
if ($error) {
    echo '<div class="lp-error-box">⚠️ &nbsp;' . $error . '</div>';
}

echo '<div class="lp-email-page">';
echo '<div class="lp-email-hero">';
echo '<div class="lp-email-hero-icon">✉️</div>';
echo '<div><h2>Send Report by Email</h2><p>Send the progress report for <strong>' . format_string($group->name) . '</strong> directly to any email address right now.</p></div>';
echo '</div>';

echo '<form method="post" action="">';
echo html_writer::empty_tag('input', ['type' => 'hidden', 'name' => 'sesskey', 'value' => sesskey()]);
echo html_writer::empty_tag('input', ['type' => 'hidden', 'name' => 'send',    'value' => 1]);

// Recipients
echo '<div class="lp-form-section">';
echo '<h3>📧 Recipients</h3>';
echo '<div class="lp-form-field">';
echo '<label for="recipients">Email Addresses</label>';
echo '<textarea name="recipients" id="recipients" rows="3" placeholder="email@example.com, another@company.com, third@org.net"></textarea>';
echo '<span style="font-size:.74rem;color:#9ca3af;font-family:var(--lp-font);margin-top:4px">Separate multiple email addresses with commas</span>';
echo '</div></div>';

// Format & View
echo '<div class="lp-form-section">';
echo '<h3>📄 Report Options</h3>';

echo '<div style="margin-bottom:14px">';
echo '<label style="font-size:.76rem;font-weight:600;color:#6b7280;text-transform:uppercase;letter-spacing:.4px;font-family:var(--lp-font);display:block;margin-bottom:10px">File Format</label>';
echo '<div class="lp-format-grid">';
$fmts = ['xlsx' => ['📊','Excel','Best for editing & analysis'], 'csv' => ['📄','CSV','Universal, lightweight'], 'pdf' => ['📑','PDF','Ready to share & print']];
foreach ($fmts as $val => [$icon, $name, $desc]) {
    $checked = $val === 'xlsx' ? ' checked' : '';
    echo '<div>';
    echo '<input type="radio" name="format" id="fmt_' . $val . '" value="' . $val . '" class="lp-format-option"' . $checked . '>';
    echo '<label for="fmt_' . $val . '" class="lp-format-label">';
    echo '<span class="fmt-icon">' . $icon . '</span>';
    echo '<span class="fmt-name">' . $name . '</span>';
    echo '<span class="fmt-desc">' . $desc . '</span>';
    echo '</label></div>';
}
echo '</div></div>';

echo '<div class="lp-form-row">';
echo '<div class="lp-form-field"><label>View Mode</label>';
echo '<select name="view"><option value="detail">📋 Per-course detail</option><option value="summary">👤 Learner summary</option></select></div>';
echo '</div>';
echo '</div>';

echo '<div class="lp-form-actions">';
echo '<button type="submit" class="lp-btn lp-btn-primary" style="font-family:var(--lp-font);font-size:.9rem;padding:10px 24px">✉️ Send Report Now</button>';
echo html_writer::link(new moodle_url('/local/learnpath/schedule.php', ['groupid' => $groupid]), '📅 Set up a scheduled report instead', ['style' => 'font-family:var(--lp-font);font-size:.84rem;color:#1a56db;text-decoration:none']);
echo '</div>';

echo '</form></div>';
echo $OUTPUT->footer();
