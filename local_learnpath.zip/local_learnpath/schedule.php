<?php
require_once(__DIR__ . '/../../config.php');
use local_learnpath\data_helper;
use local_learnpath\form\schedule_form;
use local_learnpath\task\send_scheduled_reports;

require_login();
$syscontext = context_system::instance();
require_capability('local/learnpath:emailreport', $syscontext);

$groupid    = required_param('groupid', PARAM_INT);
$action     = optional_param('action',     'list', PARAM_ALPHA);
$scheduleid = optional_param('scheduleid', 0,      PARAM_INT);

$group = data_helper::get_group_with_courses($groupid);
if (!$group) throw new moodle_exception('invalidgroup', 'local_learnpath');

$PAGE->set_url(new moodle_url('/local/learnpath/schedule.php', ['groupid' => $groupid, 'action' => $action]));
$PAGE->set_context($syscontext);
$PAGE->set_pagelayout('report');
$PAGE->set_title('Scheduled Reports — ' . format_string($group->name));
$PAGE->set_heading('Scheduled Reports');
$PAGE->requires->css('/local/learnpath/styles.css');

global $DB, $OUTPUT, $USER;

if ($action === 'delete' && $scheduleid && confirm_sesskey()) {
    $DB->delete_records('local_learnpath_schedules', ['id' => $scheduleid, 'groupid' => $groupid]);
    redirect(new moodle_url('/local/learnpath/schedule.php', ['groupid' => $groupid]),
        'Schedule deleted.', null, \core\output\notification::NOTIFY_SUCCESS);
}

if ($action === 'toggle' && $scheduleid && confirm_sesskey()) {
    $s = $DB->get_record('local_learnpath_schedules', ['id' => $scheduleid, 'groupid' => $groupid]);
    if ($s) {
        $DB->update_record('local_learnpath_schedules', (object)['id' => $s->id, 'enabled' => $s->enabled ? 0 : 1]);
    }
    redirect(new moodle_url('/local/learnpath/schedule.php', ['groupid' => $groupid]));
}

if ($action === 'add' || ($action === 'edit' && $scheduleid)) {
    $customdata = ['groupid' => $groupid, 'id' => 0];
    if ($scheduleid) {
        $s = $DB->get_record('local_learnpath_schedules', ['id' => $scheduleid, 'groupid' => $groupid], '*', MUST_EXIST);
        $customdata = array_merge($customdata, (array)$s);
    }
    $form = new schedule_form($PAGE->url, $customdata);
    if ($form->is_cancelled()) {
        redirect(new moodle_url('/local/learnpath/schedule.php', ['groupid' => $groupid]));
    }
    if ($data = $form->get_data()) {
        $rec = (object)['groupid' => $groupid, 'recipients' => trim($data->recipients),
            'frequency' => $data->frequency, 'format' => $data->format, 'enabled' => !empty($data->enabled) ? 1 : 0];
        if (!empty($data->id)) {
            $rec->id = $data->id;
            $DB->update_record('local_learnpath_schedules', $rec);
        } else {
            $rec->createdby = $USER->id; $rec->timecreated = time();
            $rec->nextrun   = send_scheduled_reports::next_run($data->frequency, time());
            $DB->insert_record('local_learnpath_schedules', $rec);
        }
        redirect(new moodle_url('/local/learnpath/schedule.php', ['groupid' => $groupid]),
            'Schedule saved.', null, \core\output\notification::NOTIFY_SUCCESS);
    }
    echo $OUTPUT->header();
    echo '<style>
    .lp-sched-form { max-width: 600px; }
    .lp-sched-hero { background: linear-gradient(135deg, #0f172a, #4c1d95); border-radius:16px; padding:24px 28px; color:white; margin-bottom:20px; font-family:var(--lp-font); display:flex; align-items:center; gap:16px; }
    .lp-sched-hero-icon { font-size:2rem; }
    .lp-sched-hero h2 { font-size:1.2rem; font-weight:700; margin:0 0 4px; }
    .lp-sched-hero p { font-size:.82rem; color:rgba(255,255,255,.72); margin:0; }
    .lp-form-section { background:white; border:1px solid #e5e7eb; border-radius:12px; padding:22px; margin-bottom:16px; font-family:var(--lp-font); }
    .lp-form-section h3 { font-size:.82rem; font-weight:700; text-transform:uppercase; letter-spacing:.5px; color:#6b7280; margin:0 0 14px; }
    </style>';
    echo html_writer::link(new moodle_url('/local/learnpath/schedule.php', ['groupid' => $groupid]), '← Back to Schedules', ['style' => 'display:inline-block;margin-bottom:16px;font-family:var(--lp-font);font-size:.85rem;color:#1a56db;text-decoration:none']);
    echo '<div class="lp-sched-form">';
    echo '<div class="lp-sched-hero"><div class="lp-sched-hero-icon">📅</div><div><h2>' . ($scheduleid ? 'Edit Schedule' : 'New Schedule') . '</h2><p>' . format_string($group->name) . '</p></div></div>';
    echo '<div class="lp-form-section">';
    $form->set_data($customdata);
    $form->display();
    echo '</div></div>';
    echo $OUTPUT->footer();
    exit;
}

// ── LIST ──────────────────────────────────────────────────────────────────────
echo $OUTPUT->header();
?>
<style>
.lp-sched-page { max-width: 900px; }
.lp-sched-hero {
    background: linear-gradient(135deg, #0f172a, #4c1d95);
    border-radius: 16px; padding: 28px 32px; color: white;
    margin-bottom: 24px; display: flex; align-items: center;
    justify-content: space-between; flex-wrap: wrap; gap: 16px;
    font-family: var(--lp-font);
}
.lp-sched-hero-left { display: flex; align-items: center; gap: 16px; }
.lp-sched-hero-icon { font-size: 2.4rem; }
.lp-sched-hero h2 { font-size: 1.3rem; font-weight: 700; margin: 0 0 4px; }
.lp-sched-hero p  { font-size: .85rem; color: rgba(255,255,255,.72); margin: 0; }
.lp-sched-card {
    background: white; border: 1px solid #e5e7eb; border-radius: 12px;
    padding: 20px; margin-bottom: 14px; font-family: var(--lp-font);
    display: flex; align-items: center; gap: 16px; flex-wrap: wrap;
    box-shadow: 0 1px 3px rgba(0,0,0,.05); transition: box-shadow .15s;
}
.lp-sched-card:hover { box-shadow: 0 4px 16px rgba(0,0,0,.08); }
.lp-sched-card-icon {
    width: 48px; height: 48px; border-radius: 12px; flex-shrink: 0;
    display: flex; align-items: center; justify-content: center; font-size: 1.4rem;
}
.lp-sched-card-icon.daily   { background: #fef3c7; }
.lp-sched-card-icon.weekly  { background: #dbeafe; }
.lp-sched-card-icon.monthly { background: #d1fae5; }
.lp-sched-card-info { flex: 1; min-width: 0; }
.lp-sched-card-title { font-size: .95rem; font-weight: 700; color: #111827; margin: 0 0 4px; }
.lp-sched-card-meta  { font-size: .78rem; color: #6b7280; margin: 0; }
.lp-sched-card-actions { display: flex; gap: 8px; flex-wrap: wrap; }
.lp-pill-enabled  { background: #d1fae5; color: #065f46; font-size:.72rem; font-weight:700; padding:2px 10px; border-radius:100px; }
.lp-pill-disabled { background: #f3f4f6; color: #9ca3af; font-size:.72rem; font-weight:700; padding:2px 10px; border-radius:100px; }
</style>

<?php
echo html_writer::link(new moodle_url('/local/learnpath/index.php', ['groupid' => $groupid]), '← Back to Dashboard', ['style' => 'display:inline-block;margin-bottom:16px;font-family:var(--lp-font);font-size:.85rem;color:#1a56db;text-decoration:none']);

echo '<div class="lp-sched-page">';
echo '<div class="lp-sched-hero">';
echo '<div class="lp-sched-hero-left"><div class="lp-sched-hero-icon">📅</div>';
echo '<div><h2>Scheduled Reports</h2><p>' . format_string($group->name) . ' — Automate recurring progress reports by email</p></div>';
echo '</div>';
echo html_writer::link(
    new moodle_url('/local/learnpath/schedule.php', ['groupid' => $groupid, 'action' => 'add']),
    '+ Add Schedule', ['style' => 'background:white;color:#4c1d95;font-family:var(--lp-font);font-weight:700;padding:9px 18px;border-radius:9px;text-decoration:none;font-size:.88rem']
);
echo '</div>';

$schedules = $DB->get_records('local_learnpath_schedules', ['groupid' => $groupid]);
$freq_icons = ['daily' => '⚡', 'weekly' => '📆', 'monthly' => '🗓️'];
$freq_labels = ['daily' => 'Daily', 'weekly' => 'Weekly', 'monthly' => 'Monthly'];
$fmt_labels  = ['xlsx' => 'Excel (.xlsx)', 'csv' => 'CSV', 'pdf' => 'PDF'];

if (empty($schedules)) {
    echo '<div class="lp-empty-state">';
    echo '<div class="lp-empty-icon">📅</div>';
    echo '<h3 class="lp-empty-title">No scheduled reports yet</h3>';
    echo '<p class="lp-empty-desc">Set up automated reports to be sent to any email address on a daily, weekly, or monthly basis.</p>';
    echo html_writer::link(new moodle_url('/local/learnpath/schedule.php', ['groupid' => $groupid, 'action' => 'add']), '+ Add your first schedule', ['class' => 'lp-btn lp-btn-primary']);
    echo '</div>';
} else {
    foreach ($schedules as $s) {
        $freq    = $s->frequency ?? 'weekly';
        $editurl = new moodle_url('/local/learnpath/schedule.php', ['groupid' => $groupid, 'action' => 'edit', 'scheduleid' => $s->id]);
        $delurl  = new moodle_url('/local/learnpath/schedule.php', ['groupid' => $groupid, 'action' => 'delete', 'scheduleid' => $s->id, 'sesskey' => sesskey()]);
        $togurl  = new moodle_url('/local/learnpath/schedule.php', ['groupid' => $groupid, 'action' => 'toggle', 'scheduleid' => $s->id, 'sesskey' => sesskey()]);

        echo '<div class="lp-sched-card">';
        echo '<div class="lp-sched-card-icon ' . $freq . '">' . ($freq_icons[$freq] ?? '📅') . '</div>';
        echo '<div class="lp-sched-card-info">';
        echo '<p class="lp-sched-card-title">' . ($freq_labels[$freq] ?? ucfirst($freq)) . ' — ' . strtoupper($fmt_labels[$s->format] ?? $s->format) . ' &nbsp;' . ($s->enabled ? '<span class="lp-pill-enabled">Active</span>' : '<span class="lp-pill-disabled">Paused</span>') . '</p>';
        echo '<p class="lp-sched-card-meta">📧 ' . htmlspecialchars($s->recipients) . '<br>';
        echo '🕐 Next run: ' . userdate($s->nextrun) . ($s->lastrun ? ' &nbsp;·&nbsp; Last sent: ' . userdate($s->lastrun) : '') . '</p>';
        echo '</div>';
        echo '<div class="lp-sched-card-actions">';
        echo html_writer::link($togurl, $s->enabled ? '⏸ Pause' : '▶ Resume', ['class' => 'lp-action-btn lp-view']);
        echo html_writer::link($editurl, '✏️ Edit', ['class' => 'lp-action-btn lp-edit']);
        echo html_writer::link($delurl, '🗑 Delete', ['class' => 'lp-action-btn lp-delete', 'onclick' => "return confirm('Delete this schedule?')"]);
        echo '</div></div>';
    }
}

echo '</div>';
echo $OUTPUT->footer();
