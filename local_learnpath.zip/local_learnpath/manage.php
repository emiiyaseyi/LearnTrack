<?php
/**
 * Manage Learning Path groups.
 *
 * ROOT CAUSE FIX for get_data() returning null:
 *   When the form constructor receives null (default) or a plain string URL,
 *   Moodle strips all query parameters from the form action. On POST, `action=add`
 *   is lost, so the page thinks action='list' and never runs the save block.
 *
 *   THE FIX: Pass $PAGE->url (a moodle_url object) to the form constructor.
 *   Moodle converts every query parameter in the moodle_url into a hidden <input>
 *   field, so `action=add` survives the POST intact.
 *
 * Reference: formslib.php Usage - MoodleDocs; MDL-73242; MDL-71831; MDL-78411
 */

require_once(__DIR__ . '/../../config.php');

use local_learnpath\form\group_form;

require_login();
$syscontext = context_system::instance();
require_capability('local/learnpath:manage', $syscontext);

// Read params BEFORE set_url so we can embed them in the page URL
$action  = optional_param('action',  'list', PARAM_ALPHA);
$groupid = optional_param('groupid', 0,      PARAM_INT);
$debug   = optional_param('debug',   0,      PARAM_INT);

// ── CRITICAL: set_url must contain ALL params the page needs ──────────────────
// $PAGE->url is what gets passed to the form constructor as the form action.
// Every key in this moodle_url becomes a hidden <input> field in the HTML form.
// This is the only way query params survive a POST request.
// ─────────────────────────────────────────────────────────────────────────────
$PAGE->set_url(new moodle_url('/local/learnpath/manage.php', [
    'action'  => $action,
    'groupid' => $groupid,
]));
$PAGE->set_context($syscontext);
$PAGE->set_pagelayout('report');
$PAGE->set_title(get_string('manage_paths', 'local_learnpath'));
$PAGE->set_heading(get_string('manage_paths', 'local_learnpath'));
$PAGE->requires->css('/local/learnpath/styles.css');

global $DB, $USER, $OUTPUT;

// ── DELETE ────────────────────────────────────────────────────────────────────
if ($action === 'delete' && $groupid > 0 && confirm_sesskey()) {
    $DB->delete_records('local_learnpath_group_courses', ['groupid' => $groupid]);
    $DB->delete_records('local_learnpath_schedules',     ['groupid' => $groupid]);
    $DB->delete_records('local_learnpath_groups',        ['id'      => $groupid]);
    redirect(
        new moodle_url('/local/learnpath/manage.php'),
        get_string('group_deleted', 'local_learnpath'),
        null,
        \core\output\notification::NOTIFY_SUCCESS
    );
}

// ── ADD / EDIT ────────────────────────────────────────────────────────────────
if ($action === 'add' || ($action === 'edit' && $groupid > 0)) {

    // Pre-populate form data for edit
    $formdata = (object)['id' => 0];
    if ($action === 'edit' && $groupid > 0) {
        $formdata = $DB->get_record('local_learnpath_groups', ['id' => $groupid], '*', MUST_EXIST);
        $formdata->courseids = array_values(
            $DB->get_fieldset_select('local_learnpath_group_courses', 'courseid', 'groupid = ?', [$groupid])
        );
    }

    // ── THE FIX: pass $PAGE->url (moodle_url object), NOT null or a string ──
    // This makes Moodle inject action=add (or edit) + groupid as hidden fields
    // so they survive the POST and the page knows to run the save block.
    $mform = new group_form($PAGE->url);
    $mform->set_data($formdata);

    if ($mform->is_cancelled()) {
        redirect(new moodle_url('/local/learnpath/manage.php'));

    } else if ($data = $mform->get_data()) {
        // ── get_data() returned data — form was valid and submitted ──────────
        $now = time();

        // Clean and filter courseids — remove marker values and zero IDs
        $courseids = [];
        if ($data->grouptype === 'manual') {
            $raw = $data->courseids ?? [];
            if (!is_array($raw)) {
                $raw = [$raw];
            }
            $courseids = array_values(array_filter(array_map('intval', $raw), fn($v) => $v > 0));
        } elseif ($data->grouptype === 'category' && !empty($data->categoryid)) {
            $rows = $DB->get_records('course', ['category' => (int)$data->categoryid, 'visible' => 1], '', 'id');
            $courseids = array_keys($rows);
        } elseif ($data->grouptype === 'cohort' && !empty($data->cohortid)) {
            $rows = $DB->get_records_sql(
                "SELECT DISTINCT e.courseid FROM {enrol} e
                 JOIN {cohort_enrolments} ce ON ce.enrolid = e.id
                 WHERE ce.cohortid = :cid AND e.enrol = 'cohort'",
                ['cid' => (int)$data->cohortid]
            );
            $courseids = array_column($rows, 'courseid');
        }

        if (!empty($data->id)) {
            // UPDATE existing record
            $DB->update_record('local_learnpath_groups', (object)[
                'id'           => (int)$data->id,
                'name'         => trim($data->name),
                'description'  => (string)($data->description ?? ''),
                'grouptype'    => $data->grouptype,
                'categoryid'   => !empty($data->categoryid) ? (int)$data->categoryid : null,
                'cohortid'     => !empty($data->cohortid)   ? (int)$data->cohortid   : null,
                'timemodified' => $now,
            ]);
            $savedid = (int)$data->id;
            $DB->delete_records('local_learnpath_group_courses', ['groupid' => $savedid]);
        } else {
            // INSERT new record — let DB assign ID, capture return value
            $savedid = (int)$DB->insert_record('local_learnpath_groups', (object)[
                'name'         => trim($data->name),
                'description'  => (string)($data->description ?? ''),
                'grouptype'    => $data->grouptype,
                'categoryid'   => !empty($data->categoryid) ? (int)$data->categoryid : null,
                'cohortid'     => !empty($data->cohortid)   ? (int)$data->cohortid   : null,
                'createdby'    => (int)$USER->id,
                'timecreated'  => $now,
                'timemodified' => $now,
            ]);
        }

        // Insert course links
        $sort = 0;
        foreach ($courseids as $cid) {
            if ((int)$cid <= 0) continue;
            $DB->insert_record('local_learnpath_group_courses', (object)[
                'groupid'   => $savedid,
                'courseid'  => (int)$cid,
                'sortorder' => $sort++,
            ]);
        }

        redirect(
            new moodle_url('/local/learnpath/manage.php'),
            get_string('group_saved', 'local_learnpath') .
                ' ✓ (ID: ' . $savedid . ', ' . count($courseids) . ' course(s) linked)',
            null,
            \core\output\notification::NOTIFY_SUCCESS
        );

    } else {
        // Form not yet submitted or failed validation — display it
        echo $OUTPUT->header();
        echo lp_page_header(
            $action === 'edit' ? get_string('edit_group', 'local_learnpath') : get_string('add_group', 'local_learnpath'),
            '',
            new moodle_url('/local/learnpath/manage.php'),
            true
        );
        echo html_writer::start_div('lp-card lp-form-card');
        $mform->display();
        echo html_writer::end_div();
        echo lp_dev_footer();
        echo $OUTPUT->footer();
    }
    exit;
}

// ── LIST ──────────────────────────────────────────────────────────────────────
echo $OUTPUT->header();
echo lp_page_header(
    get_string('manage_paths', 'local_learnpath'),
    get_string('manage_paths_subtitle', 'local_learnpath'),
    new moodle_url('/local/learnpath/index.php'),
    true
);

echo html_writer::div(
    '🔒 &nbsp;<strong>' . get_string('admin_only_notice', 'local_learnpath') . '</strong>'
    . ' — ' . get_string('admin_only_notice_desc', 'local_learnpath'),
    'lp-admin-badge'
);

$addurl   = new moodle_url('/local/learnpath/manage.php', ['action' => 'add']);
$debugurl = new moodle_url('/local/learnpath/manage.php', ['debug'  => 1]);

echo html_writer::start_div('lp-toolbar');
echo html_writer::link($addurl, '+ &nbsp;' . get_string('add_group', 'local_learnpath'), ['class' => 'lp-btn lp-btn-primary']);
if (!$debug) {
    echo html_writer::link($debugurl, '🔧 Diagnostics', ['class' => 'lp-btn lp-btn-export']);
}
echo html_writer::end_div();

// ── DEBUG PANEL ───────────────────────────────────────────────────────────────
if ($debug) {
    echo html_writer::start_div('lp-debug-panel');
    echo html_writer::tag('h4', '🔧 Database Diagnostics', ['style' => 'margin:0 0 10px;color:#a3e635']);
    foreach (['local_learnpath_groups', 'local_learnpath_group_courses', 'local_learnpath_schedules'] as $t) {
        $exists = $DB->get_manager()->table_exists($t);
        $count  = $exists ? $DB->count_records($t) : '—';
        echo html_writer::tag('p', ($exists ? '✅' : '❌') . ' ' . $t . ' (' . $count . ' rows)');
    }
    $allgroups = $DB->get_records('local_learnpath_groups');
    if ($allgroups) {
        echo html_writer::tag('p', '📋 Groups:', ['style' => 'margin-top:10px']);
        echo html_writer::tag('pre', print_r($allgroups, true));
    } else {
        echo html_writer::tag('p', '⚠️ No groups found in DB', ['style' => 'color:#f87171']);
    }
    echo html_writer::end_div();
}

// ── GROUP LIST ────────────────────────────────────────────────────────────────
$groups = $DB->get_records('local_learnpath_groups', null, 'name ASC');

if (empty($groups)) {
    echo html_writer::div(
        html_writer::div('📂', 'lp-empty-icon') .
        html_writer::tag('h3', get_string('no_groups', 'local_learnpath'), ['class' => 'lp-empty-title']) .
        html_writer::tag('p', get_string('no_groups_hint', 'local_learnpath'), ['class' => 'lp-empty-desc']) .
        html_writer::link($addurl, '+ &nbsp;' . get_string('add_group', 'local_learnpath'), ['class' => 'lp-btn lp-btn-primary']),
        'lp-empty-state'
    );
} else {
    echo html_writer::start_div('lp-card');
    echo html_writer::start_tag('table', ['class' => 'lp-table']);
    echo html_writer::tag('thead',
        html_writer::tag('tr',
            html_writer::tag('th', get_string('group_name',        'local_learnpath')) .
            html_writer::tag('th', get_string('group_type',        'local_learnpath')) .
            html_writer::tag('th', get_string('group_coursecount', 'local_learnpath')) .
            html_writer::tag('th', get_string('actions'))
        )
    );
    echo html_writer::start_tag('tbody');

    foreach ($groups as $g) {
        $count    = $DB->count_records('local_learnpath_group_courses', ['groupid' => $g->id]);
        $editurl  = new moodle_url('/local/learnpath/manage.php',   ['action' => 'edit',   'groupid' => $g->id]);
        $delurl   = new moodle_url('/local/learnpath/manage.php',   ['action' => 'delete', 'groupid' => $g->id, 'sesskey' => sesskey()]);
        $viewurl  = new moodle_url('/local/learnpath/index.php',    ['groupid' => $g->id]);
        $schedurl = new moodle_url('/local/learnpath/schedule.php', ['groupid' => $g->id]);

        echo html_writer::tag('tr',
            html_writer::tag('td', html_writer::tag('strong', format_string($g->name))) .
            html_writer::tag('td', html_writer::tag('span', get_string('grouptype_' . $g->grouptype, 'local_learnpath'), ['class' => 'lp-type-badge lp-type-' . $g->grouptype])) .
            html_writer::tag('td', html_writer::tag('span', $count . ' course' . ($count != 1 ? 's' : ''), ['class' => 'lp-course-count'])) .
            html_writer::tag('td',
                html_writer::link($viewurl,  '👁 View',     ['class' => 'lp-action-btn lp-view']) .
                html_writer::link($editurl,  '✏️ Edit',     ['class' => 'lp-action-btn lp-edit']) .
                html_writer::link($schedurl, '📅 Schedule', ['class' => 'lp-action-btn lp-schedule']) .
                html_writer::link($delurl,   '🗑 Delete',   [
                    'class'   => 'lp-action-btn lp-delete',
                    'onclick' => "return confirm('" . get_string('confirm_delete_group', 'local_learnpath') . "');",
                ]),
                ['class' => 'lp-actions-cell']
            )
        );
    }

    echo html_writer::end_tag('tbody');
    echo html_writer::end_tag('table');
    echo html_writer::end_div();
}

echo lp_dev_footer();
echo $OUTPUT->footer();


// ── HELPERS ───────────────────────────────────────────────────────────────────

function lp_page_header(string $title, string $subtitle = '', ?moodle_url $backurl = null, bool $showback = false): string {
    $back = ($showback && $backurl)
        ? html_writer::link($backurl, '← ' . get_string('back_to_dashboard', 'local_learnpath'), ['class' => 'lp-back-link'])
        : '';
    return html_writer::div(
        $back .
        html_writer::tag('h1', $title, ['class' => 'lp-page-title']) .
        ($subtitle ? html_writer::tag('p', $subtitle, ['class' => 'lp-page-subtitle']) : ''),
        'lp-page-header'
    );
}

function lp_dev_footer(): string {
    return html_writer::div(
        html_writer::tag('span', '© Michael Adeniran') . ' · ' .
        html_writer::link('mailto:michaeladeniransnr@gmail.com', 'michaeladeniransnr@gmail.com') . ' · ' .
        html_writer::link('https://www.linkedin.com/in/michaeladeniran', 'LinkedIn', ['target' => '_blank', 'rel' => 'noopener']) . ' · ' .
        html_writer::tag('span', '🇳🇬 Nigeria') . ' · ' .
        html_writer::tag('span', 'v1.2.0 · Moodle 4.5 – 5.1+'),
        'lp-developer-footer'
    );
}
