<?php
namespace local_learnpath\form;

defined('MOODLE_INTERNAL') || die();
require_once($GLOBALS['CFG']->libdir . '/formslib.php');

/**
 * Form for creating/editing a learning path group.
 *
 * KEY FIXES applied (based on Moodle tracker research):
 * - MDL-73242: Never use addRule('required') on fields with hideIf — causes silent validation failure
 * - MDL-71831: Never use addRule('required') on autocomplete multi-select — marker value bypasses it
 * - MDL-78411: addRule + autocomplete causes JS TypeError that blocks form submission silently
 * - All validation is done server-side in validation() instead
 * - PARAM_INT on autocomplete multi-select is correct — each array value is individually cast
 * - The form is passed a moodle_url object so action= param is preserved as a hidden field
 */
class group_form extends \moodleform {

    public function definition(): void {
        global $DB;
        $mform = $this->_form;

        // Hidden fields — id is the record ID for edits (0 = new)
        $mform->addElement('hidden', 'id', 0);
        $mform->setType('id', PARAM_INT);

        // Path name — only this uses addRule('required') because it is a plain text field (safe)
        $mform->addElement('text', 'name', get_string('group_name', 'local_learnpath'), ['size' => 60]);
        $mform->setType('name', PARAM_TEXT);
        $mform->addRule('name', get_string('required'), 'required', null, 'client');

        // Description
        $mform->addElement('textarea', 'description', get_string('group_description', 'local_learnpath'), [
            'rows' => 3, 'cols' => 60,
        ]);
        $mform->setType('description', PARAM_TEXT);

        // Group type selector
        $mform->addElement('select', 'grouptype', get_string('group_type', 'local_learnpath'), [
            'manual'   => get_string('grouptype_manual',   'local_learnpath'),
            'category' => get_string('grouptype_category', 'local_learnpath'),
            'cohort'   => get_string('grouptype_cohort',   'local_learnpath'),
        ]);
        $mform->setType('grouptype', PARAM_ALPHA);
        $mform->setDefault('grouptype', 'manual');

        // Category selector
        $categories = $DB->get_records_menu('course_categories', null, 'name ASC', 'id, name');
        $categories = ['' => get_string('choosedots')] + $categories;
        $mform->addElement('select', 'categoryid', get_string('group_category', 'local_learnpath'), $categories);
        $mform->setType('categoryid', PARAM_INT);
        $mform->setDefault('categoryid', 0);
        // NO addRule required here — validated in validation() only
        $mform->hideIf('categoryid', 'grouptype', 'neq', 'category');

        // Cohort selector
        $cohorts = $DB->get_records_menu('cohort', null, 'name ASC', 'id, name');
        $cohorts = ['' => get_string('choosedots')] + $cohorts;
        $mform->addElement('select', 'cohortid', get_string('group_cohort', 'local_learnpath'), $cohorts);
        $mform->setType('cohortid', PARAM_INT);
        $mform->setDefault('cohortid', 0);
        // NO addRule required here — validated in validation() only
        $mform->hideIf('cohortid', 'grouptype', 'neq', 'cohort');

        // Course multi-select (manual mode)
        // PARAM_INT on autocomplete multi-select: each element individually cast — correct and safe
        // NO addRule('required') — MDL-71831 + MDL-78411 make this silently break submission
        $courseoptions = $DB->get_records_menu('course', ['visible' => 1], 'fullname ASC', 'id, fullname');
        unset($courseoptions[SITEID]);
        $mform->addElement('autocomplete', 'courseids',
            get_string('group_courses', 'local_learnpath'),
            $courseoptions,
            ['multiple' => true, 'noselectionstring' => get_string('choosedots')]
        );
        $mform->setType('courseids', PARAM_INT);
        // NO addRule required — validated in validation() only
        $mform->hideIf('courseids', 'grouptype', 'neq', 'manual');

        $this->add_action_buttons();
    }

    /**
     * Server-side validation only — no addRule('required') used on conditional fields.
     * This is the ONLY place conditional field requirements are enforced.
     */
    public function validation($data, $files): array {
        $errors = parent::validation($data, $files);

        $type = $data['grouptype'] ?? 'manual';

        if ($type === 'category') {
            if (empty($data['categoryid']) || (int)$data['categoryid'] <= 0) {
                $errors['categoryid'] = get_string('required');
            }
        }

        if ($type === 'cohort') {
            if (empty($data['cohortid']) || (int)$data['cohortid'] <= 0) {
                $errors['cohortid'] = get_string('required');
            }
        }

        if ($type === 'manual') {
            // Filter out the Moodle multi-select force-submission marker and zero values
            $courseids = $data['courseids'] ?? [];
            if (!is_array($courseids)) {
                $courseids = [$courseids];
            }
            $courseids = array_filter($courseids, fn($v) => intval($v) > 0);
            if (empty($courseids)) {
                $errors['courseids'] = get_string('required');
            }
        }

        return $errors;
    }
}
