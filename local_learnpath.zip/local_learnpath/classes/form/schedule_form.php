<?php
namespace local_learnpath\form;

defined('MOODLE_INTERNAL') || die();
require_once($GLOBALS['CFG']->libdir . '/formslib.php');

/**
 * Form for scheduling email reports.
 */
class schedule_form extends \moodleform {

    public function definition(): void {
        $mform = $this->_form;

        $mform->addElement('hidden', 'id',      0);
        $mform->addElement('hidden', 'groupid', 0);
        $mform->setType('id',      PARAM_INT);
        $mform->setType('groupid', PARAM_INT);

        // Recipients
        $mform->addElement('textarea', 'recipients',
            get_string('schedule_recipients', 'local_learnpath'),
            ['rows' => 4, 'cols' => 60]
        );
        $mform->setType('recipients', PARAM_TEXT);
        $mform->addRule('recipients', null, 'required', null, 'client');
        $mform->addHelpButton('recipients', 'schedule_recipients', 'local_learnpath');

        // Frequency
        $mform->addElement('select', 'frequency', get_string('schedule_frequency', 'local_learnpath'), [
            'daily'   => get_string('frequency_daily',   'local_learnpath'),
            'weekly'  => get_string('frequency_weekly',  'local_learnpath'),
            'monthly' => get_string('frequency_monthly', 'local_learnpath'),
        ]);

        // Format
        $mform->addElement('select', 'format', get_string('schedule_format', 'local_learnpath'), [
            'xlsx' => 'Excel (.xlsx)',
            'csv'  => 'CSV',
            'pdf'  => 'PDF',
        ]);

        // Enabled
        $mform->addElement('checkbox', 'enabled', get_string('schedule_enabled', 'local_learnpath'));
        $mform->setDefault('enabled', 1);

        $this->add_action_buttons();
    }

    public function validation($data, $files): array {
        $errors = parent::validation($data, $files);
        $emails = array_map('trim', explode(',', $data['recipients']));
        foreach ($emails as $email) {
            if ($email && !validate_email($email)) {
                $errors['recipients'] = get_string('invalidemail');
                break;
            }
        }
        return $errors;
    }
}
