<?php
namespace local_learnpath\task;

defined('MOODLE_INTERNAL') || die();

use local_learnpath\export_manager;

/**
 * Scheduled task: send all due email reports.
 */
class send_scheduled_reports extends \core\task\scheduled_task {

    public function get_name(): string {
        return get_string('task_send_reports', 'local_learnpath');
    }

    public function execute(): void {
        global $DB;

        $now       = time();
        $schedules = $DB->get_records_select(
            'local_learnpath_schedules',
            'enabled = 1 AND nextrun <= :now',
            ['now' => $now]
        );

        foreach ($schedules as $schedule) {
            mtrace("LearnPath: Sending scheduled report for group {$schedule->groupid}...");

            $recipients = array_filter(array_map('trim', explode(',', $schedule->recipients)));
            try {
                export_manager::email_report(
                    $schedule->groupid,
                    $recipients,
                    $schedule->format,
                    'detail',
                    get_admin()->id
                );

                $schedule->lastrun = $now;
                $schedule->nextrun = self::next_run($schedule->frequency, $now);
                $DB->update_record('local_learnpath_schedules', $schedule);

                mtrace("LearnPath: Report sent successfully.");
            } catch (\Exception $e) {
                mtrace("LearnPath: ERROR sending report: " . $e->getMessage());
            }
        }
    }

    public static function next_run(string $frequency, int $from): int {
        switch ($frequency) {
            case 'daily':   return strtotime('+1 day', $from);
            case 'monthly': return strtotime('+1 month', $from);
            case 'weekly':
            default:        return strtotime('+1 week', $from);
        }
    }
}
