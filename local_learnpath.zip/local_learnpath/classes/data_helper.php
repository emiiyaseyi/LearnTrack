<?php
namespace local_learnpath;

defined('MOODLE_INTERNAL') || die();

/**
 * Data helper: fetches learner progress across a learning path group.
 */
class data_helper {

    /**
     * Get all learning path groups.
     */
    public static function get_groups(): array {
        global $DB;
        return $DB->get_records('local_learnpath_groups', null, 'name ASC');
    }

    /**
     * Get a single group with its courses.
     */
    public static function get_group_with_courses(int $groupid): ?object {
        global $DB;
        $group = $DB->get_record('local_learnpath_groups', ['id' => $groupid]);
        if (!$group) {
            return null;
        }
        $group->courses = self::get_group_courses($groupid);
        return $group;
    }

    /**
     * Get courses for a group.
     */
    public static function get_group_courses(int $groupid): array {
        global $DB;
        $sql = "SELECT c.id, c.fullname, c.shortname, lgc.sortorder
                FROM {course} c
                JOIN {local_learnpath_group_courses} lgc ON lgc.courseid = c.id
                WHERE lgc.groupid = :groupid
                ORDER BY lgc.sortorder ASC, c.fullname ASC";
        return $DB->get_records_sql($sql, ['groupid' => $groupid]);
    }

    /**
     * Get learners enrolled in at least one course in the group.
     * Respects the restrict_by_group setting and viewall capability.
     */
    public static function get_learners_for_group(int $groupid, int $viewerid): array {
        global $DB, $CFG;

        $courses = self::get_group_courses($groupid);
        if (empty($courses)) {
            return [];
        }

        $courseids = array_keys($courses);
        list($insql, $params) = $DB->get_in_or_equal($courseids, SQL_PARAMS_NAMED, 'cid');

        $restrictbygroup = get_config('local_learnpath', 'restrict_by_group');
        $canviewall = has_capability('local/learnpath:viewall', \context_system::instance(), $viewerid);

        $sql = "SELECT DISTINCT u.id, u.firstname, u.lastname, u.email, u.username
                FROM {user} u
                JOIN {user_enrolments} ue ON ue.userid = u.id
                JOIN {enrol} e ON e.id = ue.enrolid AND e.courseid $insql
                WHERE u.deleted = 0 AND u.suspended = 0";

        if ($restrictbygroup && !$canviewall) {
            // Only show learners who share a group/cohort with the viewer
            $sql .= " AND (
                EXISTS (
                    SELECT 1 FROM {groups_members} gm1
                    JOIN {groups_members} gm2 ON gm2.groupid = gm1.groupid
                    WHERE gm1.userid = :viewerid1 AND gm2.userid = u.id
                )
                OR EXISTS (
                    SELECT 1 FROM {cohort_members} cm1
                    JOIN {cohort_members} cm2 ON cm2.cohortid = cm1.cohortid
                    WHERE cm1.userid = :viewerid2 AND cm2.userid = u.id
                )
            )";
            $params['viewerid1'] = $viewerid;
            $params['viewerid2'] = $viewerid;
        }

        $sql .= " ORDER BY u.lastname ASC, u.firstname ASC";
        return $DB->get_records_sql($sql, $params);
    }

    /**
     * Get full progress data for a learner across all courses in a group.
     * Returns one row per learner-course combination.
     */
    public static function get_progress_detail(int $groupid, int $viewerid): array {
        global $DB;

        $courses  = self::get_group_courses($groupid);
        $learners = self::get_learners_for_group($groupid, $viewerid);

        if (empty($courses) || empty($learners)) {
            return [];
        }

        $rows = [];

        foreach ($learners as $learner) {
            foreach ($courses as $course) {
                $row = new \stdClass();
                $row->userid      = $learner->id;
                $row->firstname   = $learner->firstname;
                $row->lastname    = $learner->lastname;
                $row->email       = $learner->email;
                $row->username    = $learner->username;
                $row->courseid    = $course->id;
                $row->coursename  = $course->fullname;

                // Completion status
                $completion = $DB->get_record('course_completions', [
                    'userid'   => $learner->id,
                    'course'   => $course->id,
                ]);
                $row->completed      = !empty($completion->timecompleted);
                $row->timecompleted  = $completion->timecompleted ?? null;

                // First / last access
                $logdata = $DB->get_record_sql(
                    "SELECT MIN(timecreated) AS firstaccess, MAX(timecreated) AS lastaccess
                     FROM {logstore_standard_log}
                     WHERE userid = :uid AND courseid = :cid AND action = 'viewed'",
                    ['uid' => $learner->id, 'cid' => $course->id]
                );
                $row->firstaccess = $logdata->firstaccess ?? null;
                $row->lastaccess  = $logdata->lastaccess  ?? null;

                // Total activities & completed activities
                $ctx = \context_course::instance($course->id, IGNORE_MISSING);
                if ($ctx) {
                    $row->total_activities = $DB->count_records_sql(
                        "SELECT COUNT(cm.id) FROM {course_modules} cm
                         JOIN {modules} m ON m.id = cm.module
                         WHERE cm.course = :cid AND cm.completion > 0 AND cm.deletioninprogress = 0",
                        ['cid' => $course->id]
                    );
                    $row->completed_activities = $DB->count_records_sql(
                        "SELECT COUNT(cmc.id) FROM {course_modules_completion} cmc
                         JOIN {course_modules} cm ON cm.id = cmc.coursemoduleid
                         WHERE cm.course = :cid AND cmc.userid = :uid
                           AND cmc.completionstate IN (1,2)",
                        ['cid' => $course->id, 'uid' => $learner->id]
                    );
                } else {
                    $row->total_activities     = 0;
                    $row->completed_activities = 0;
                }

                // Progress percentage
                $row->progress = ($row->total_activities > 0)
                    ? round(($row->completed_activities / $row->total_activities) * 100)
                    : ($row->completed ? 100 : 0);

                // Grade
                require_once($GLOBALS['CFG']->libdir . '/gradelib.php');
                $grade_info = grade_get_course_grade($learner->id, $course->id);
                $row->grade     = $grade_info ? round((float)$grade_info->grade, 1) : null;
                $row->maxgrade  = $grade_info ? round((float)$grade_info->item->grademax, 1) : null;

                // Status label
                if ($row->completed) {
                    $row->status = 'complete';
                } elseif ($row->progress > 0) {
                    $row->status = 'inprogress';
                } elseif ($row->firstaccess) {
                    $row->status = 'inprogress';
                } else {
                    $row->status = 'notstarted';
                }

                $rows[] = $row;
            }
        }

        return $rows;
    }

    /**
     * Summarise progress: one row per learner, aggregated across all courses.
     */
    public static function get_progress_summary(int $groupid, int $viewerid): array {
        $detail  = self::get_progress_detail($groupid, $viewerid);
        $courses = self::get_group_courses($groupid);
        $total   = count($courses);

        $summary = [];
        foreach ($detail as $row) {
            $uid = $row->userid;
            if (!isset($summary[$uid])) {
                $summary[$uid] = (object)[
                    'userid'              => $uid,
                    'firstname'           => $row->firstname,
                    'lastname'            => $row->lastname,
                    'email'               => $row->email,
                    'username'            => $row->username,
                    'total_courses'       => $total,
                    'completed_courses'   => 0,
                    'inprogress_courses'  => 0,
                    'notstarted_courses'  => 0,
                    'overall_progress'    => 0,
                    'firstaccess'         => null,
                    'lastaccess'          => null,
                ];
            }
            $s = $summary[$uid];
            if ($row->status === 'complete')    $s->completed_courses++;
            if ($row->status === 'inprogress')  $s->inprogress_courses++;
            if ($row->status === 'notstarted')  $s->notstarted_courses++;

            if ($row->firstaccess && (!$s->firstaccess || $row->firstaccess < $s->firstaccess)) {
                $s->firstaccess = $row->firstaccess;
            }
            if ($row->lastaccess && (!$s->lastaccess || $row->lastaccess > $s->lastaccess)) {
                $s->lastaccess = $row->lastaccess;
            }
        }

        // Calculate overall progress %
        foreach ($summary as $s) {
            $s->overall_progress = $total > 0 ? round(($s->completed_courses / $total) * 100) : 0;
        }

        return array_values($summary);
    }
}
