<?php
namespace local_learnpath;

defined('MOODLE_INTERNAL') || die();

/**
 * Handles exporting progress data in multiple formats.
 */
class export_manager {

    /**
     * Export progress data for a group.
     *
     * @param int    $groupid
     * @param string $format  xlsx|csv|pdf
     * @param string $view    detail|summary
     * @param int    $viewerid
     */
    public static function export(int $groupid, string $format, string $view, int $viewerid): void {
        $group = data_helper::get_group_with_courses($groupid);
        if (!$group) {
            throw new \moodle_exception('invalidgroup', 'local_learnpath');
        }

        if ($view === 'summary') {
            $data = data_helper::get_progress_summary($groupid, $viewerid);
            $headers = self::summary_headers();
            $rows    = self::summary_rows($data);
        } else {
            $data = data_helper::get_progress_detail($groupid, $viewerid);
            $headers = self::detail_headers();
            $rows    = self::detail_rows($data);
        }

        $filename = clean_filename($group->name . '_progress_' . date('Y-m-d'));

        switch ($format) {
            case 'csv':
                self::export_csv($filename, $headers, $rows);
                break;
            case 'pdf':
                self::export_pdf($filename, $group->name, $headers, $rows);
                break;
            case 'xlsx':
            default:
                self::export_xlsx($filename, $group->name, $headers, $rows);
                break;
        }
    }

    // -------------------------------------------------------------------------
    // Headers & row mappers
    // -------------------------------------------------------------------------

    private static function detail_headers(): array {
        return [
            get_string('col_firstname',            'local_learnpath'),
            get_string('col_lastname',             'local_learnpath'),
            get_string('col_email',                'local_learnpath'),
            get_string('col_username',             'local_learnpath'),
            get_string('col_coursename',           'local_learnpath'),
            get_string('col_status',               'local_learnpath'),
            get_string('col_progress',             'local_learnpath'),
            get_string('col_completed_activities', 'local_learnpath'),
            get_string('col_total_activities',     'local_learnpath'),
            get_string('col_grade',                'local_learnpath'),
            get_string('col_firstaccess',          'local_learnpath'),
            get_string('col_lastaccess',           'local_learnpath'),
            get_string('col_timecompleted',        'local_learnpath'),
        ];
    }

    private static function detail_rows(array $data): array {
        $rows = [];
        foreach ($data as $row) {
            $rows[] = [
                $row->firstname,
                $row->lastname,
                $row->email,
                $row->username,
                $row->coursename,
                get_string('status_' . $row->status, 'local_learnpath'),
                $row->progress . '%',
                $row->completed_activities,
                $row->total_activities,
                $row->grade !== null ? $row->grade . ' / ' . $row->maxgrade : '-',
                $row->firstaccess ? userdate($row->firstaccess) : '-',
                $row->lastaccess  ? userdate($row->lastaccess)  : '-',
                $row->timecompleted ? userdate($row->timecompleted) : '-',
            ];
        }
        return $rows;
    }

    private static function summary_headers(): array {
        return [
            get_string('col_firstname',           'local_learnpath'),
            get_string('col_lastname',            'local_learnpath'),
            get_string('col_email',               'local_learnpath'),
            get_string('col_username',            'local_learnpath'),
            get_string('col_total_courses',       'local_learnpath'),
            get_string('col_completed_courses',   'local_learnpath'),
            get_string('col_inprogress_courses',  'local_learnpath'),
            get_string('col_notstarted_courses',  'local_learnpath'),
            get_string('col_overall_progress',    'local_learnpath'),
            get_string('col_firstaccess',         'local_learnpath'),
            get_string('col_lastaccess',          'local_learnpath'),
        ];
    }

    private static function summary_rows(array $data): array {
        $rows = [];
        foreach ($data as $row) {
            $rows[] = [
                $row->firstname,
                $row->lastname,
                $row->email,
                $row->username,
                $row->total_courses,
                $row->completed_courses,
                $row->inprogress_courses,
                $row->notstarted_courses,
                $row->overall_progress . '%',
                $row->firstaccess ? userdate($row->firstaccess) : '-',
                $row->lastaccess  ? userdate($row->lastaccess)  : '-',
            ];
        }
        return $rows;
    }

    // -------------------------------------------------------------------------
    // Format exporters
    // -------------------------------------------------------------------------

    private static function export_csv(string $filename, array $headers, array $rows): void {
        header('Content-Type: text/csv; charset=utf-8');
        header('Content-Disposition: attachment; filename="' . $filename . '.csv"');
        $out = fopen('php://output', 'w');
        fputcsv($out, $headers);
        foreach ($rows as $row) {
            fputcsv($out, $row);
        }
        fclose($out);
        exit;
    }

    private static function export_xlsx(string $filename, string $sheetname, array $headers, array $rows): void {
        global $CFG;
        require_once($CFG->libdir . '/excellib.class.php');

        $workbook = new \MoodleExcelWorkbook('-');
        $workbook->send($filename . '.xlsx');
        $sheet = $workbook->add_worksheet($sheetname);

        // Header row - bold
        $bold = $workbook->add_format(['bold' => 1, 'bg_color' => '#1F4E79', 'color' => 'white']);
        foreach ($headers as $col => $header) {
            $sheet->write_string(0, $col, $header, $bold);
            $sheet->set_column($col, $col, 20);
        }

        // Data rows
        foreach ($rows as $ri => $row) {
            foreach ($row as $ci => $cell) {
                $sheet->write_string($ri + 1, $ci, (string)$cell);
            }
        }

        $workbook->close();
        exit;
    }

    private static function export_pdf(string $filename, string $title, array $headers, array $rows): void {
        global $CFG;
        require_once($CFG->libdir . '/pdflib.php');

        $pdf = new \pdf('L', 'mm', 'A4', true, 'UTF-8', false);
        $pdf->SetCreator('Moodle LearnPath');
        $pdf->SetTitle($title);
        $pdf->AddPage();
        $pdf->SetFont('helvetica', 'B', 14);
        $pdf->Cell(0, 10, $title, 0, 1, 'C');
        $pdf->SetFont('helvetica', '', 8);

        $colcount = count($headers);
        $colwidth = 265 / $colcount;

        // Header row
        $pdf->SetFillColor(31, 78, 121);
        $pdf->SetTextColor(255, 255, 255);
        $pdf->SetFont('helvetica', 'B', 7);
        foreach ($headers as $h) {
            $pdf->Cell($colwidth, 7, $h, 1, 0, 'C', true);
        }
        $pdf->Ln();

        // Data rows
        $pdf->SetTextColor(0, 0, 0);
        $pdf->SetFont('helvetica', '', 7);
        $fill = false;
        foreach ($rows as $row) {
            $pdf->SetFillColor($fill ? 230 : 255, $fill ? 237 : 255, $fill ? 245 : 255);
            foreach ($row as $cell) {
                $pdf->Cell($colwidth, 6, (string)$cell, 1, 0, 'L', true);
            }
            $pdf->Ln();
            $fill = !$fill;
        }

        $pdf->Output($filename . '.pdf', 'D');
        exit;
    }

    // -------------------------------------------------------------------------
    // Email
    // -------------------------------------------------------------------------

    /**
     * Build the report as a temp file and email it.
     */
    public static function email_report(int $groupid, array $recipients, string $format, string $view, int $viewerid): bool {
        global $CFG, $DB;

        $group = data_helper::get_group_with_courses($groupid);
        if (!$group) {
            return false;
        }

        if ($view === 'summary') {
            $data    = data_helper::get_progress_summary($groupid, $viewerid);
            $headers = self::summary_headers();
            $rows    = self::summary_rows($data);
        } else {
            $data    = data_helper::get_progress_detail($groupid, $viewerid);
            $headers = self::detail_headers();
            $rows    = self::detail_rows($data);
        }

        $filename = clean_filename($group->name . '_progress_' . date('Y-m-d'));
        $tmpfile  = make_temp_directory('local_learnpath') . '/' . $filename . '.' . $format;

        // Write file to temp
        if ($format === 'csv') {
            $fp = fopen($tmpfile, 'w');
            fputcsv($fp, $headers);
            foreach ($rows as $row) {
                fputcsv($fp, $row);
            }
            fclose($fp);
        } elseif ($format === 'xlsx') {
            require_once($CFG->libdir . '/excellib.class.php');
            $workbook = new \MoodleExcelWorkbook($tmpfile);
            $sheet    = $workbook->add_worksheet($group->name);
            foreach ($headers as $col => $header) {
                $sheet->write_string(0, $col, $header);
            }
            foreach ($rows as $ri => $row) {
                foreach ($row as $ci => $cell) {
                    $sheet->write_string($ri + 1, $ci, (string)$cell);
                }
            }
            $workbook->close();
        }

        $sendername = get_config('local_learnpath', 'email_sender_name') ?: get_string('pluginname', 'local_learnpath');
        $noreply    = \core_user::get_noreply_user();
        $noreply->firstname = $sendername;

        $subject = get_string('email_subject', 'local_learnpath', $group->name);
        $body    = get_string('email_body',    'local_learnpath', [
            'groupname' => $group->name,
            'date'      => userdate(time()),
            'count'     => count($rows),
        ]);

        $success = true;
        foreach ($recipients as $email) {
            $email = trim($email);
            if (!validate_email($email)) {
                continue;
            }
            $to            = new \stdClass();
            $to->email     = $email;
            $to->firstname = $email;
            $to->lastname  = '';
            $to->maildisplay = 1;
            $to->mailformat  = 1;
            $to->id          = -1;
            $to->auth        = 'manual';
            $to->deleted     = 0;
            $to->suspended   = 0;
            $to->username    = $email;
            $to->confirmed   = 1;

            $result = email_to_user($to, $noreply, $subject, $body, '', $tmpfile, $filename . '.' . $format);
            if (!$result) {
                $success = false;
            }
        }

        @unlink($tmpfile);
        return $success;
    }
}
