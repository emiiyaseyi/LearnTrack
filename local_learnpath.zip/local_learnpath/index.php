<?php
require_once(__DIR__ . '/../../config.php');
use local_learnpath\data_helper;

require_login();
$syscontext = context_system::instance();
require_capability('local/learnpath:viewdashboard', $syscontext);

$groupid = optional_param('groupid', 0,       PARAM_INT);
$view    = optional_param('view',    'detail', PARAM_ALPHA);
$search  = optional_param('search',  '',       PARAM_TEXT);
$sortcol = optional_param('sortcol', '',       PARAM_ALPHANUMEXT);
$sortdir = optional_param('sortdir', 'asc',    PARAM_ALPHA);
$course_filter = optional_param('course_filter', 0, PARAM_INT);

$PAGE->set_url(new moodle_url('/local/learnpath/index.php', [
    'groupid' => $groupid, 'view' => $view,
]));
$PAGE->set_context($syscontext);
$PAGE->set_pagelayout('report');
$PAGE->set_title(get_string('pluginname', 'local_learnpath'));
$PAGE->set_heading(get_string('pluginname', 'local_learnpath'));
$PAGE->requires->css('/local/learnpath/styles.css');

global $USER, $OUTPUT, $DB;

$isadmin   = has_capability('local/learnpath:manage',    $syscontext);
$canexport = has_capability('local/learnpath:export',    $syscontext);
$canemail  = has_capability('local/learnpath:emailreport', $syscontext);
$groups    = data_helper::get_groups();

// Branding
$brand_color    = get_config('local_learnpath', 'brand_color')  ?: '#1a56db';
$brand_name     = get_config('local_learnpath', 'brand_name')   ?: get_string('pluginname', 'local_learnpath');
$brand_subtitle = get_config('local_learnpath', 'dashboard_subtitle') ?: get_string('dashboard_subtitle', 'local_learnpath');
$show_grade     = get_config('local_learnpath', 'show_grade')       !== '0';
$show_activities= get_config('local_learnpath', 'show_activities')  !== '0';
$show_firstaccess=get_config('local_learnpath', 'show_firstaccess') !== '0';
$show_lastaccess= get_config('local_learnpath', 'show_lastaccess')  !== '0';
$show_status    = get_config('local_learnpath', 'show_status')      !== '0';
$high_contrast  = get_config('local_learnpath', 'high_contrast')    == '1';
$reduce_motion  = get_config('local_learnpath', 'reduce_motion')    == '1';
$font_size      = (int)(get_config('local_learnpath', 'brand_font_size') ?: 13);

echo $OUTPUT->header();

// Dynamic CSS overrides from branding
echo '<style>
:root {
    --lp-primary: ' . $brand_color . ';
    --lp-primary-dark: ' . $brand_color . 'cc;
    --lp-primary-pale: ' . $brand_color . '15;
    --lp-data-font-size: ' . $font_size . 'px;
}
' . ($high_contrast ? '
.lp-data-table tbody tr { border-bottom: 2px solid #374151 !important; }
.lp-badge { font-weight: 800 !important; border: 2px solid currentColor !important; }
' : '') . '
' . ($reduce_motion ? '
*, *::before, *::after { transition: none !important; animation: none !important; }
' : '') . '
.lp-data-table td { font-size: var(--lp-data-font-size); }
.lp-page-header {
    background: linear-gradient(135deg, #0f172a 0%, #1e3a5f 55%, ' . $brand_color . ' 100%) !important;
}
</style>';

// ═══════════════════════════════════════════════════════
// PAGE HEADER
// ═══════════════════════════════════════════════════════
echo '<div class="lp-page-header">';
echo '<div class="lp-header-inner">';
echo '<div class="lp-header-text">';

// Back to welcome
echo html_writer::link(new moodle_url('/local/learnpath/welcome.php'), '← About', ['class' => 'lp-back-link', 'style' => 'display:block;margin-bottom:8px']);

echo html_writer::div('📊', 'lp-header-icon');
echo html_writer::tag('h1', format_string($brand_name), ['class' => 'lp-page-title']);
echo html_writer::tag('p', format_string($brand_subtitle), ['class' => 'lp-page-subtitle']);
echo '</div>';

echo '<div class="lp-header-actions">';
if ($isadmin) {
    echo html_writer::div('🔒 Admin Access', 'lp-admin-pill');
    echo html_writer::link(new moodle_url('/local/learnpath/manage.php'), '⚙️ &nbsp;Manage Paths', ['class' => 'lp-btn lp-btn-outline']);
    echo html_writer::link(new moodle_url('/local/learnpath/branding.php'), '🎨 &nbsp;Branding', ['class' => 'lp-btn lp-btn-outline']);
}
echo '</div>';
echo '</div></div>';

// ═══════════════════════════════════════════════════════
// STATS STRIP — equal size boxes
// ═══════════════════════════════════════════════════════
if ($groupid) {
    $group   = data_helper::get_group_with_courses($groupid);
    $summary = data_helper::get_progress_summary($groupid, $USER->id);

    if ($group && $summary) {
        $total_learners  = count($summary);
        $total_courses   = count($group->courses);
        $completed_all   = count(array_filter($summary, fn($s) => $s->completed_courses >= $s->total_courses && $s->total_courses > 0));
        $avg_raw         = $total_learners > 0 ? array_sum(array_column($summary, 'overall_progress')) / $total_learners : 0;
        $avg_progress    = round($avg_raw);

        // Equal-size stat boxes with fixed height
        echo '<div class="lp-stats-strip">';
        $stats = [
            ['👥', $total_learners,         'Total Learners',   'blue'],
            ['📚', $total_courses,          'Courses in Path',  'indigo'],
            ['✅', $completed_all,          'Fully Completed',  'green'],
            ['📈', $avg_progress . '%',     'Avg. Progress',    'amber'],
        ];
        foreach ($stats as [$icon, $value, $label, $color]) {
            echo '<div class="lp-stat-card">';
            echo '<div class="lp-stat-icon lp-icon-' . $color . '">' . $icon . '</div>';
            echo '<div class="lp-stat-text">';
            echo '<span class="lp-stat-value">' . $value . '</span>';
            echo '<span class="lp-stat-label">' . $label . '</span>';
            echo '</div></div>';
        }
        echo '</div>';
    }
}

// ═══════════════════════════════════════════════════════
// TOOLBAR
// ═══════════════════════════════════════════════════════
echo '<div class="lp-toolbar-wrap">';
echo '<div class="lp-toolbar">';

// Group selector
echo '<div class="lp-toolbar-group">';
echo html_writer::tag('label', 'Learning Path', ['for' => 'lp-group-select', 'class' => 'lp-label']);
$gopts = [0 => '— Select a path —'];
foreach ($groups as $g) $gopts[$g->id] = format_string($g->name);
echo html_writer::select($gopts, 'groupid', $groupid, false, [
    'id'       => 'lp-group-select',
    'class'    => 'lp-select',
    'onchange' => "window.location='?groupid='+this.value+'&view={$view}'",
]);
echo '</div>';

if ($groupid) {
    // Course filter
    $group_courses = data_helper::get_group_courses($groupid);
    if (!empty($group_courses)) {
        echo '<div class="lp-toolbar-group">';
        echo html_writer::tag('label', 'Filter by Course', ['class' => 'lp-label']);
        $copts = [0 => 'All Courses'];
        foreach ($group_courses as $c) $copts[$c->id] = format_string($c->fullname);
        echo html_writer::select($copts, 'course_filter', $course_filter, false, [
            'class'    => 'lp-select',
            'onchange' => "window.location='?groupid={$groupid}&view={$view}&course_filter='+this.value",
        ]);
        echo '</div>';
    }

    // View toggle
    echo '<div class="lp-toolbar-group">';
    echo html_writer::tag('label', 'View', ['class' => 'lp-label']);
    echo '<div class="lp-toggle-group">';
    $durl = new moodle_url('/local/learnpath/index.php', ['groupid' => $groupid, 'view' => 'detail', 'course_filter' => $course_filter]);
    $surl = new moodle_url('/local/learnpath/index.php', ['groupid' => $groupid, 'view' => 'summary','course_filter' => $course_filter]);
    echo html_writer::link($durl, '📋 Per Course', ['class' => 'lp-toggle' . ($view === 'detail'  ? ' active' : '')]);
    echo html_writer::link($surl, '👤 Summary',    ['class' => 'lp-toggle' . ($view === 'summary' ? ' active' : '')]);
    echo '</div></div>';

    // Export
    if ($canexport) {
        echo '<div class="lp-toolbar-group">';
        echo html_writer::tag('label', 'Export', ['class' => 'lp-label']);
        echo '<div class="lp-btn-group">';
        foreach (['xlsx' => '📊 Excel', 'csv' => '📄 CSV', 'pdf' => '📑 PDF'] as $fmt => $lbl) {
            $url = new moodle_url('/local/learnpath/export.php', ['groupid' => $groupid, 'format' => $fmt, 'view' => $view, 'sesskey' => sesskey()]);
            echo html_writer::link($url, $lbl, ['class' => 'lp-btn lp-btn-export']);
        }
        echo '</div></div>';
    }

    // Email / Schedule
    if ($canemail) {
        echo '<div class="lp-toolbar-group">';
        echo html_writer::tag('label', 'Reports', ['class' => 'lp-label']);
        echo '<div class="lp-btn-group">';
        echo html_writer::link(new moodle_url('/local/learnpath/email.php',    ['groupid' => $groupid]), '✉️ Send Now',   ['class' => 'lp-btn lp-btn-email']);
        echo html_writer::link(new moodle_url('/local/learnpath/schedule.php', ['groupid' => $groupid]), '📅 Schedule',  ['class' => 'lp-btn lp-btn-schedule']);
        echo '</div></div>';
    }
}

echo '</div>'; // .lp-toolbar

// Search row
if ($groupid) {
    echo '<div class="lp-search-bar">';
    echo '<span class="lp-search-icon">🔍</span>';
    echo '<input type="text" id="lp-search" class="lp-search-input" placeholder="Search by learner name, email, or username…" value="' . s($search) . '">';
    echo '<span style="font-size:.78rem;color:#9ca3af;font-family:var(--lp-font);margin-left:8px" id="lp-result-count"></span>';
    echo '</div>';
}

echo '</div>'; // .lp-toolbar-wrap

// ═══════════════════════════════════════════════════════
// DATA TABLE
// ═══════════════════════════════════════════════════════
if (!$groupid) {
    echo '<div class="lp-empty-state">';
    echo '<div class="lp-empty-icon">📊</div>';
    echo '<h3 class="lp-empty-title">Select a Learning Path</h3>';
    echo html_writer::tag('p', 'Choose a learning path from the dropdown above to view learner progress.', ['class' => 'lp-empty-desc']);
    if ($isadmin && empty($groups)) {
        echo html_writer::link(new moodle_url('/local/learnpath/manage.php', ['action' => 'add']), '+ Create your first learning path', ['class' => 'lp-btn lp-btn-primary']);
    }
    echo '</div>';
} else {
    $group = data_helper::get_group_with_courses($groupid);
    if (!$group) {
        echo $OUTPUT->notification('Invalid learning path.', 'error');
    } else {
        echo '<div class="lp-card lp-table-card">';
        echo '<div class="lp-card-header">';
        echo html_writer::tag('h3', format_string($group->name), ['class' => 'lp-card-title']);
        echo html_writer::tag('span', count($group->courses) . ' courses', ['class' => 'lp-card-meta']);
        echo '</div>';

        if ($view === 'summary') {
            $data = data_helper::get_progress_summary($groupid, $USER->id);
            // Apply course filter (n/a for summary — show all)
            lp_render_summary_table($data, $sortcol, $sortdir, $groupid);
        } else {
            $data = data_helper::get_progress_detail($groupid, $USER->id);
            // Apply course filter
            if ($course_filter > 0) {
                $data = array_filter($data, fn($r) => (int)$r->courseid === $course_filter);
            }
            lp_render_detail_table($data, $sortcol, $sortdir, $groupid, $view, $course_filter,
                $show_grade, $show_activities, $show_firstaccess, $show_lastaccess, $show_status);
        }

        if (empty($data)) {
            echo '<div class="lp-empty-state">';
            echo '<div class="lp-empty-icon">📭</div>';
            echo html_writer::tag('p', 'No data found for the selected filters.', ['class' => 'lp-empty-desc']);
            echo '</div>';
        }
        echo '</div>';
    }
}

// ═══════════════════════════════════════════════════════
// FOOTER
// ═══════════════════════════════════════════════════════
echo '<div class="lp-developer-footer">';
echo '<span>© Michael Adeniran</span><span class="lp-sep">·</span>';
echo html_writer::link('mailto:michaeladeniransnr@gmail.com', 'michaeladeniransnr@gmail.com');
echo '<span class="lp-sep">·</span>';
echo html_writer::link('https://www.linkedin.com/in/michaeladeniran', 'LinkedIn', ['target' => '_blank']);
echo '<span class="lp-sep">·</span><span>🇳🇬 Nigeria</span>';
echo '<span class="lp-sep">·</span><span>Learning Path Progress v1.3.0</span>';
echo '</div>';

// ═══════════════════════════════════════════════════════
// CLIENT-SIDE: search + sort + row count
// ═══════════════════════════════════════════════════════
echo html_writer::script("
document.addEventListener('DOMContentLoaded', function() {
    // Live search
    var inp = document.getElementById('lp-search');
    var ctr = document.getElementById('lp-result-count');
    if (inp) {
        function doSearch() {
            var q = inp.value.toLowerCase();
            var rows = document.querySelectorAll('.lp-data-table tbody tr');
            var visible = 0;
            rows.forEach(function(r) {
                var show = !q || r.textContent.toLowerCase().includes(q);
                r.style.display = show ? '' : 'none';
                if (show) visible++;
            });
            if (ctr) ctr.textContent = q ? visible + ' result(s)' : '';
        }
        inp.addEventListener('input', doSearch);
    }

    // Column sorting
    document.querySelectorAll('.lp-sort-th').forEach(function(th) {
        th.style.cursor = 'pointer';
        th.addEventListener('click', function() {
            var col = this.dataset.col;
            var dir = this.dataset.dir === 'asc' ? 'desc' : 'asc';
            var url = new URL(window.location.href);
            url.searchParams.set('sortcol', col);
            url.searchParams.set('sortdir', dir);
            window.location = url.toString();
        });
    });
});
");

echo $OUTPUT->footer();

// ═══════════════════════════════════════════════════════
// RENDER FUNCTIONS
// ═══════════════════════════════════════════════════════

function lp_sort_icon(string $col, string $current, string $dir): string {
    if ($col !== $current) return ' <span style="opacity:.3;font-size:.7rem">↕</span>';
    return $dir === 'asc' ? ' <span style="font-size:.7rem">↑</span>' : ' <span style="font-size:.7rem">↓</span>';
}

function lp_th(string $col, string $label, string $sortcol, string $sortdir, int $groupid, string $view, int $cfilter): string {
    $icon = lp_sort_icon($col, $sortcol, $sortdir);
    return '<th class="lp-sort-th" data-col="' . $col . '" data-dir="' . ($sortcol === $col ? $sortdir : 'asc') . '" title="Sort by ' . $label . '">' . $label . $icon . '</th>';
}

function lp_sort_data(array $data, string $col, string $dir): array {
    if (!$col) return $data;
    usort($data, function($a, $b) use ($col, $dir) {
        $av = $a->$col ?? '';
        $bv = $b->$col ?? '';
        $r = is_numeric($av) ? ($av <=> $bv) : strcasecmp((string)$av, (string)$bv);
        return $dir === 'desc' ? -$r : $r;
    });
    return $data;
}

function lp_render_detail_table(array $data, string $sortcol, string $sortdir, int $groupid, string $view, int $cfilter,
    bool $show_grade, bool $show_activities, bool $show_firstaccess, bool $show_lastaccess, bool $show_status): void {
    if (empty($data)) return;
    $data = lp_sort_data($data, $sortcol, $sortdir);
    echo '<div class="lp-table-scroll">';
    echo '<table class="lp-data-table">';
    echo '<thead><tr>';
    echo lp_th('lastname',            'Learner',      $sortcol, $sortdir, $groupid, $view, $cfilter);
    echo lp_th('email',               'Email',        $sortcol, $sortdir, $groupid, $view, $cfilter);
    echo lp_th('coursename',          'Course',       $sortcol, $sortdir, $groupid, $view, $cfilter);
    if ($show_status)    echo lp_th('status',    'Status',     $sortcol, $sortdir, $groupid, $view, $cfilter);
    echo lp_th('progress',            'Progress',     $sortcol, $sortdir, $groupid, $view, $cfilter);
    if ($show_activities) echo lp_th('completed_activities', 'Activities', $sortcol, $sortdir, $groupid, $view, $cfilter);
    if ($show_grade)     echo lp_th('grade',     'Grade',      $sortcol, $sortdir, $groupid, $view, $cfilter);
    if ($show_firstaccess) echo lp_th('firstaccess', 'First Access', $sortcol, $sortdir, $groupid, $view, $cfilter);
    if ($show_lastaccess)  echo lp_th('lastaccess',  'Last Access',  $sortcol, $sortdir, $groupid, $view, $cfilter);
    echo lp_th('timecompleted', 'Date Completed', $sortcol, $sortdir, $groupid, $view, $cfilter);
    echo '</tr></thead><tbody>';

    foreach ($data as $row) {
        // ── 100% COMPLETION FIX ──────────────────────────────────────────────
        // If course_completions shows timecompleted, force 100% regardless of activity count
        $pct = (int)$row->progress;
        if ($row->completed && $pct < 100) $pct = 100;
        // Re-derive status after fix
        $status = $row->status;
        if ($pct === 100) $status = 'complete';

        echo '<tr>';
        echo '<td>' . html_writer::div(format_string($row->firstname . ' ' . $row->lastname), 'lp-learner-name') . html_writer::div($row->username, 'lp-learner-sub') . '</td>';
        echo '<td>' . html_writer::tag('a', $row->email, ['href' => 'mailto:' . $row->email, 'class' => 'lp-email']) . '</td>';
        echo '<td>' . html_writer::div(format_string($row->coursename), 'lp-course-name') . '</td>';
        if ($show_status)    echo '<td>' . lp_status_badge($status) . '</td>';
        echo '<td>' . lp_progress_bar($pct, $status) . '</td>';
        if ($show_activities) echo '<td>' . html_writer::tag('span', $row->completed_activities . '/' . $row->total_activities, ['class' => 'lp-activity-count']) . '</td>';
        if ($show_grade)     echo '<td>' . ($row->grade !== null ? html_writer::tag('span', $row->grade . '/' . $row->maxgrade, ['class' => 'lp-grade']) : html_writer::tag('span', '—', ['class' => 'lp-na'])) . '</td>';
        if ($show_firstaccess) echo '<td>' . ($row->firstaccess   ? html_writer::tag('span', userdate($row->firstaccess,   get_string('strftimedatefullshort')), ['class' => 'lp-date']) : html_writer::tag('span', '—', ['class' => 'lp-na'])) . '</td>';
        if ($show_lastaccess)  echo '<td>' . ($row->lastaccess    ? html_writer::tag('span', userdate($row->lastaccess,    get_string('strftimedatefullshort')), ['class' => 'lp-date']) : html_writer::tag('span', '—', ['class' => 'lp-na'])) . '</td>';
        echo '<td>' . ($row->timecompleted ? html_writer::tag('span', userdate($row->timecompleted, get_string('strftimedatefullshort')), ['class' => 'lp-date lp-date-done']) : html_writer::tag('span', '—', ['class' => 'lp-na'])) . '</td>';
        echo '</tr>';
    }
    echo '</tbody></table></div>';
}

function lp_render_summary_table(array $data, string $sortcol, string $sortdir, int $groupid): void {
    if (empty($data)) return;
    $data = lp_sort_data($data, $sortcol, $sortdir);
    echo '<div class="lp-table-scroll">';
    echo '<table class="lp-data-table"><thead><tr>';
    $cols = [
        ['lastname','Learner'], ['email','Email'], ['total_courses','Total'],
        ['completed_courses','Completed'], ['inprogress_courses','In Progress'],
        ['notstarted_courses','Not Started'], ['overall_progress','Progress'],
        ['firstaccess','First Access'], ['lastaccess','Last Access'],
    ];
    foreach ($cols as [$col, $lbl]) echo lp_th($col, $lbl, $sortcol, $sortdir, $groupid, 'summary', 0);
    echo '</tr></thead><tbody>';
    foreach ($data as $row) {
        // Fix summary progress: if all courses complete, force 100%
        $pct = (int)$row->overall_progress;
        if ($row->completed_courses >= $row->total_courses && $row->total_courses > 0) $pct = 100;
        $status = $pct === 100 ? 'complete' : ($row->inprogress_courses > 0 ? 'inprogress' : 'notstarted');
        echo '<tr>';
        echo '<td>' . html_writer::div(format_string($row->firstname . ' ' . $row->lastname), 'lp-learner-name') . html_writer::div($row->username, 'lp-learner-sub') . '</td>';
        echo '<td>' . html_writer::tag('a', $row->email, ['href' => 'mailto:' . $row->email, 'class' => 'lp-email']) . '</td>';
        echo '<td>' . html_writer::tag('span', $row->total_courses, ['class' => 'lp-num']) . '</td>';
        echo '<td>' . html_writer::tag('span', $row->completed_courses,  ['class' => 'lp-num lp-green']) . '</td>';
        echo '<td>' . html_writer::tag('span', $row->inprogress_courses, ['class' => 'lp-num lp-amber']) . '</td>';
        echo '<td>' . html_writer::tag('span', $row->notstarted_courses, ['class' => 'lp-num lp-grey']) . '</td>';
        echo '<td>' . lp_progress_bar($pct, $status) . '</td>';
        echo '<td>' . ($row->firstaccess ? html_writer::tag('span', userdate($row->firstaccess, get_string('strftimedatefullshort')), ['class' => 'lp-date']) : html_writer::tag('span', '—', ['class' => 'lp-na'])) . '</td>';
        echo '<td>' . ($row->lastaccess  ? html_writer::tag('span', userdate($row->lastaccess,  get_string('strftimedatefullshort')), ['class' => 'lp-date']) : html_writer::tag('span', '—', ['class' => 'lp-na'])) . '</td>';
        echo '</tr>';
    }
    echo '</tbody></table></div>';
}

function lp_progress_bar(int $pct, string $status): string {
    $cls = match($status) { 'complete' => 'lp-bar-complete', 'inprogress' => 'lp-bar-progress', default => 'lp-bar-empty' };
    return '<div class="lp-progress-wrap"><div class="lp-progress-track"><div class="lp-progress-fill ' . $cls . '" style="width:' . $pct . '%"></div></div><span class="lp-progress-pct">' . $pct . '%</span></div>';
}

function lp_status_badge(string $status): string {
    $map = ['complete' => ['lp-badge-complete','✓ Completed'], 'inprogress' => ['lp-badge-inprogress','⏳ In Progress'], 'notstarted' => ['lp-badge-notstarted','○ Not Started']];
    [$cls, $label] = $map[$status] ?? ['lp-badge-notstarted', '○ Unknown'];
    return html_writer::tag('span', $label, ['class' => 'lp-badge ' . $cls]);
}
