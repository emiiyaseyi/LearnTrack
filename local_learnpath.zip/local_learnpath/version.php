<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// =============================================================
// Learning Path Progress Dashboard
// =============================================================
// Developer : Michael Adeniran
// Email     : michaeladeniransnr@gmail.com
// LinkedIn  : https://www.linkedin.com/in/michaeladeniran
// Country   : Nigeria
// Copyright : (C) 2025 Michael Adeniran
// License   : GNU GPL v3 or later
// =============================================================
// Compatible with Moodle 4.5, 5.0, 5.1 and later versions.
// For Moodle 5.1+: place plugin in /public/local/learnpath/
// For Moodle 4.5 - 5.0: place plugin in /local/learnpath/
// =============================================================

defined('MOODLE_INTERNAL') || die();

$plugin->component  = 'local_learnpath';
$plugin->version    = 2025010500;
$plugin->requires   = 2024100700;
$plugin->maturity   = MATURITY_STABLE;
$plugin->release    = '1.3.0 — Welcome, Branding, Sortable columns, 100% fix (Moodle 4.5-5.1+)';

// Declare supported Moodle version range [min_branch, max_branch].
// 405 = Moodle 4.5, 501 = Moodle 5.1. This range covers all versions in between.
// Increment the upper bound (e.g. 502, 503) as new Moodle versions are tested.
$plugin->supported  = [405, 501];
